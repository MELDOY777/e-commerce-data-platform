# src/visualization.py
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import font_manager
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
try:
    plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
except:
    print("注意: 中文字体设置失败，图表可能无法显示中文")

class EcommerceVisualizer:
    def __init__(self, data_path="data"):
        """初始化可视化器"""
        self.data_path = data_path
        self.data = self.load_data()
        self.color_palette = sns.color_palette("husl", 10)
        
    def load_data(self):
        """加载数据"""
        print("📂 加载数据...")
        data = {}
        
        files = ['users', 'orders', 'products', 'user_behavior', 'refunds']
        for file in files:
            try:
                if file == 'orders':
                    data[file] = pd.read_csv(f"{self.data_path}/raw/{file}.csv", parse_dates=['order_date'])
                elif file == 'user_behavior':
                    data[file] = pd.read_csv(f"{self.data_path}/raw/{file}.csv", parse_dates=['event_time'])
                elif file == 'refunds':
                    data[file] = pd.read_csv(f"{self.data_path}/raw/{file}.csv", parse_dates=['refund_date'])
                elif file == 'users':
                    data[file] = pd.read_csv(f"{self.data_path}/raw/{file}.csv", parse_dates=['registration_date'])
                else:
                    data[file] = pd.read_csv(f"{self.data_path}/raw/{file}.csv")
                print(f"  ✓ {file}: {len(data[file])} 条")
            except:
                print(f"  ⓘ {file}: 文件不存在")
                data[file] = pd.DataFrame()
        
        return data
    
    def create_sales_dashboard(self):
        """创建销售仪表板"""
        print("📈 生成销售仪表板...")
        
        orders = self.data['orders']
        
        # 创建子图
        fig = make_subplots(
            rows=3, cols=3,
            subplot_titles=(
                '月度销售趋势', '周度销售分布', '小时销售热力图',
                '品类销售占比', '品牌销售TOP10', '支付方式分布',
                '销售地域分布', '客单价分布', '折扣率分布'
            ),
            specs=[
                [{'type': 'scatter'}, {'type': 'bar'}, {'type': 'heatmap'}],
                [{'type': 'pie'}, {'type': 'bar'}, {'type': 'bar'}],
                [{'type': 'bar'}, {'type': 'histogram'}, {'type': 'histogram'}]  # 第3行第1列改为bar
            ]
        )
        
        # 1. 月度销售趋势
        orders['month'] = orders['order_date'].dt.to_period('M').astype(str)
        monthly_sales = orders.groupby('month')['total_amount'].sum().reset_index()
        
        fig.add_trace(
            go.Scatter(
                x=monthly_sales['month'],
                y=monthly_sales['total_amount'],
                mode='lines+markers',
                name='月度销售额',
                line=dict(color='#FF6B6B', width=3),
                fill='tozeroy',
                fillcolor='rgba(255, 107, 107, 0.1)'
            ),
            row=1, col=1
        )
        
        # 2. 周度销售分布
        orders['weekday'] = orders['order_date'].dt.day_name()
        weekday_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        weekday_sales = orders.groupby('weekday')['total_amount'].sum().reindex(weekday_order)
        
        fig.add_trace(
            go.Bar(
                x=weekday_sales.index,
                y=weekday_sales.values,
                name='周度销售',
                marker_color='#4ECDC4'
            ),
            row=1, col=2
        )
        
        # 3. 小时销售热力图
        orders['hour'] = orders['order_date'].dt.hour
        orders['date'] = orders['order_date'].dt.date
        hourly_heatmap = orders.pivot_table(
            values='total_amount',
            index='date',
            columns='hour',
            aggfunc='sum',
            fill_value=0
        )
        
        fig.add_trace(
            go.Heatmap(
                z=hourly_heatmap.values,
                x=hourly_heatmap.columns,
                y=hourly_heatmap.index.astype(str),
                colorscale='Viridis',
                name='小时销售热力图'
            ),
            row=1, col=3
        )
        
        # 4. 品类销售占比
        category_sales = orders.groupby('category')['total_amount'].sum()
        fig.add_trace(
            go.Pie(
                labels=category_sales.index,
                values=category_sales.values,
                hole=0.4,
                name='品类占比',
                marker_colors=px.colors.qualitative.Set3
            ),
            row=2, col=1
        )
        
        # 5. 品牌销售TOP10
        brand_sales = orders.groupby('brand')['total_amount'].sum().nlargest(10)
        fig.add_trace(
            go.Bar(
                x=brand_sales.values,
                y=brand_sales.index,
                orientation='h',
                name='品牌TOP10',
                marker_color='#45B7D1'
            ),
            row=2, col=2
        )
        
        # 6. 支付方式分布
        payment_dist = orders['payment_method'].value_counts()
        fig.add_trace(
            go.Bar(
                x=payment_dist.index,
                y=payment_dist.values,
                name='支付方式',
                marker_color='#96CEB4'
            ),
            row=2, col=3
        )
        
        # 7. 销售地域分布（简化版）
        if 'shipping_city' in orders.columns:
            city_sales = orders.groupby('shipping_city')['total_amount'].sum().nlargest(15)
            fig.add_trace(
                go.Bar(
                    x=city_sales.index,
                    y=city_sales.values,
                    name='城市销售',
                    marker_color='#FFEAA7'
                ),
                row=3, col=1
            )
        
        # 8. 客单价分布
        customer_stats = orders.groupby('user_id')['total_amount'].sum()
        fig.add_trace(
            go.Histogram(
                x=customer_stats.values,
                nbinsx=30,
                name='客单价分布',
                marker_color='#DDA0DD'
            ),
            row=3, col=2
        )
        
        # 9. 折扣率分布
        fig.add_trace(
            go.Histogram(
                x=orders['discount_rate'],
                nbinsx=20,
                name='折扣率分布',
                marker_color='#98D8C8'
            ),
            row=3, col=3
        )
        
        # 更新布局
        fig.update_layout(
            title_text='电商销售综合仪表板',
            height=1200,
            showlegend=False,
            template='plotly_white'
        )
        
        # 保存图表
        fig.write_html("data/analysis/sales_dashboard.html")
        print("  ✓ 销售仪表板已保存: data/analysis/sales_dashboard.html")
        
        return fig
    
    def create_customer_analysis_charts(self):
        """创建客户分析图表"""
        print("👥 生成客户分析图表...")
        
        orders = self.data['orders']
        users = self.data['users']
        
        # 聚合数据（会产生多级列）
        order_agg = orders.groupby('user_id').agg({
            'total_amount': 'sum',
            'order_id': 'count',
            'order_date': ['min', 'max']
        }).reset_index()
        
        # 扁平化列名
        order_agg.columns = ['_'.join(col).strip().rstrip('_') for col in order_agg.columns.values]
        
        # 重命名列
        order_agg = order_agg.rename(columns={
            'user_id_': 'user_id',
            'total_amount_sum': 'total_spent',
            'order_id_count': 'order_count',
            'order_date_min': 'first_purchase',
            'order_date_max': 'last_purchase'
        })
        
        # 合并数据
        customer_data = pd.merge(
            order_agg,
            users,
            on='user_id'
        )
        
        customer_data.columns = ['user_id', 'total_spent', 'order_count', 'first_purchase', 'last_purchase', 
                                'username', 'name', 'email', 'phone', 'age', 'gender', 'city', 
                                'province', 'registration_date', 'membership_level', 'total_spent_orig', 'order_count_orig', 'last_purchase_date']
        
        # 创建子图
        fig = make_subplots(
            rows=2, cols=3,
            subplot_titles=(
                '客户年龄分布', '会员等级分布', '客户消费能力分析',
                'RFM客户细分', '客户生命周期价值', '客户地域分布'
            ),
            specs=[
                [{'type': 'histogram'}, {'type': 'pie'}, {'type': 'scatter'}],
                [{'type': 'bar'}, {'type': 'box'}, {'type': 'bar'}]  # 第2行第3列改为bar
            ]
        )
        
        # 1. 客户年龄分布
        fig.add_trace(
            go.Histogram(
                x=customer_data['age'],
                nbinsx=10,
                name='年龄分布',
                marker_color='#FF6B6B'
            ),
            row=1, col=1
        )
        
        # 2. 会员等级分布
        membership_dist = customer_data['membership_level'].value_counts()
        fig.add_trace(
            go.Pie(
                labels=membership_dist.index,
                values=membership_dist.values,
                hole=0.3,
                name='会员等级',
                marker_colors=px.colors.sequential.RdBu
            ),
            row=1, col=2
        )
        
        # 3. 客户消费能力分析（年龄 vs 消费）
        fig.add_trace(
            go.Scatter(
                x=customer_data['age'],
                y=customer_data['total_spent'],
                mode='markers',
                marker=dict(
                    size=customer_data['order_count'] * 2,
                    color=customer_data['order_count'],
                    colorscale='Viridis',
                    showscale=True
                ),
                text=customer_data['name'],
                name='消费能力'
            ),
            row=1, col=3
        )
        
        # 4. RFM客户细分（简化版）
        analysis_date = orders['order_date'].max()
        rfm = orders.groupby('user_id').agg({
            'order_date': lambda x: (analysis_date - x.max()).days,
            'order_id': 'count',
            'total_amount': 'sum'
        })
        
        rfm.columns = ['Recency', 'Frequency', 'Monetary']
        
        # 简单分段
        rfm['Segment'] = pd.qcut(rfm['Monetary'], 4, labels=['低价值', '中价值', '高价值', 'VIP'])
        segment_counts = rfm['Segment'].value_counts()
        
        fig.add_trace(
            go.Bar(
                x=segment_counts.index,
                y=segment_counts.values,
                name='RFM细分',
                marker_color=['#95E1D3', '#FCE38A', '#F38181', '#A8D8EA']
            ),
            row=2, col=1
        )
        
        # 5. 客户生命周期价值分布
        clv = customer_data['total_spent'] / customer_data['order_count'].replace(0, 1)
        fig.add_trace(
            go.Box(
                y=clv,
                name='CLV分布',
                marker_color='#4ECDC4'
            ),
            row=2, col=2
        )
        
        # 6. 客户地域分布（城市销售TOP15）
        if 'city' in customer_data.columns:
            city_dist = customer_data['city'].value_counts().head(15)
            fig.add_trace(
                go.Bar(
                    x=city_dist.values,
                    y=city_dist.index,
                    orientation='h',
                    name='客户地域分布',
                    marker_color='#FFD3B6'
                ),
                row=2, col=3
            )
        
        # 更新布局
        fig.update_layout(
            title_text='客户分析仪表板',
            height=800,
            showlegend=False,
            template='plotly_white'
        )
        
        # 保存图表
        fig.write_html("data/analysis/customer_dashboard.html")
        print("  ✓ 客户分析仪表板已保存: data/analysis/customer_dashboard.html")
        
        return fig
    
    def create_product_analysis_charts(self):
        """创建产品分析图表"""
        print("📦 生成产品分析图表...")
        
        orders = self.data['orders']
        products = self.data['products']
        
        # 产品统计
        product_stats = orders.groupby('product_id').agg({
            'total_amount': ['sum', 'count'],
            'quantity': 'sum',
            'unit_price': 'mean'
        }).round(2)
        
        product_stats.columns = ['sales_amount', 'order_count', 'quantity_sold', 'avg_price']
        product_stats = product_stats.reset_index()
        
        # 关联产品信息
        product_stats = pd.merge(product_stats, products, left_on='product_id', right_on='id')
        
        # 创建子图
        fig = make_subplots(
            rows=2, cols=3,
            subplot_titles=(
                '产品销售TOP10', '品类销售分布', '价格vs销量关系',
                '品牌市场份额', '产品价格分布', '库存周转分析'
            ),
            specs=[
                [{'type': 'bar'}, {'type': 'sunburst'}, {'type': 'scatter'}],
                [{'type': 'treemap'}, {'type': 'violin'}, {'type': 'funnel'}]
            ]
        )
        
        # 1. 产品销售TOP10
        top_products = product_stats.nlargest(10, 'sales_amount')
        fig.add_trace(
            go.Bar(
                x=top_products['name'],
                y=top_products['sales_amount'],
                name='热销产品',
                marker_color='#FF6B6B',
                text=top_products['sales_amount'].apply(lambda x: f'¥{x:,.0f}'),
                textposition='auto'
            ),
            row=1, col=1
        )
        
        # 2. 品类销售分布（旭日图）
        category_brand_sales = orders.groupby(['category', 'brand'])['total_amount'].sum().reset_index()
        fig.add_trace(
            go.Sunburst(
                labels=list(category_brand_sales['category']) + list(category_brand_sales['brand']),
                parents=[''] * len(category_brand_sales['category']) + list(category_brand_sales['category']),
                values=list(category_brand_sales['total_amount']) * 2,
                branchvalues="total",
                name='品类品牌分布'
            ),
            row=1, col=2
        )
        
        # 3. 价格vs销量关系
        fig.add_trace(
            go.Scatter(
                x=product_stats['avg_price'],
                y=product_stats['quantity_sold'],
                mode='markers',
                marker=dict(
                    size=product_stats['sales_amount'] / 1000,
                    color=product_stats['sales_amount'],
                    colorscale='Viridis',
                    showscale=True,
                    sizemode='area',
                    sizeref=2.*max(product_stats['sales_amount'])/(40.**2),
                    sizemin=4
                ),
                text=product_stats['name'],
                name='价格销量关系'
            ),
            row=1, col=3
        )
        
        # 4. 品牌市场份额（树状图）
        brand_sales = orders.groupby('brand')['total_amount'].sum().reset_index()
        fig.add_trace(
            go.Treemap(
                labels=brand_sales['brand'],
                parents=[''] * len(brand_sales),
                values=brand_sales['total_amount'],
                textinfo="label+value+percent parent",
                name='品牌市场份额'
            ),
            row=2, col=1
        )
        
        # 5. 产品价格分布
        fig.add_trace(
            go.Violin(
                y=product_stats['avg_price'],
                box_visible=True,
                meanline_visible=True,
                name='价格分布',
                marker_color='#4ECDC4'
            ),
            row=2, col=2
        )
        
        # 6. 库存周转分析（漏斗图 - 假设数据）
        funnel_data = pd.DataFrame({
            'stage': ['浏览', '点击', '加购', '购买'],
            'value': [10000, 5000, 1000, 500]  # 示例数据
        })
        
        fig.add_trace(
            go.Funnel(
                y=funnel_data['stage'],
                x=funnel_data['value'],
                textinfo="value+percent initial",
                name='转化漏斗'
            ),
            row=2, col=3
        )
        
        # 更新布局
        fig.update_layout(
            title_text='产品分析仪表板',
            height=900,
            showlegend=False,
            template='plotly_white'
        )
        
        # 保存图表
        fig.write_html("data/analysis/product_dashboard.html")
        print("  ✓ 产品分析仪表板已保存: data/analysis/product_dashboard.html")
        
        return fig
    
    def create_behavior_analysis_charts(self):
        """创建用户行为分析图表"""
        print("🖱️ 生成用户行为分析图表...")
        
        if self.data['user_behavior'].empty:
            print("  ⓘ 无用户行为数据，跳过生成")
            return None
        
        behavior = self.data['user_behavior']
        
        # 创建子图
        fig = make_subplots(
            rows=2, cols=3,
            subplot_titles=(
                '行为类型分布', '用户活跃时段', '设备使用分布',
                '页面停留时间', '会话分析', '用户行为路径'
            ),
            specs=[
                [{'type': 'pie'}, {'type': 'bar'}, {'type': 'bar'}],
                [{'type': 'histogram'}, {'type': 'scatter'}, {'type': 'sankey'}]
            ]
        )
        
        # 1. 行为类型分布
        behavior_counts = behavior['behavior_type'].value_counts()
        fig.add_trace(
            go.Pie(
                labels=behavior_counts.index,
                values=behavior_counts.values,
                hole=0.3,
                name='行为类型',
                marker_colors=px.colors.qualitative.Set2
            ),
            row=1, col=1
        )
        
        # 2. 用户活跃时段
        behavior['hour'] = behavior['event_time'].dt.hour
        hourly_activity = behavior.groupby('hour').size()
        
        fig.add_trace(
            go.Bar(
                x=hourly_activity.index,
                y=hourly_activity.values,
                name='活跃时段',
                marker_color='#FFA726'
            ),
            row=1, col=2
        )
        
        # 3. 设备使用分布
        device_dist = behavior['device'].value_counts()
        fig.add_trace(
            go.Bar(
                x=device_dist.index,
                y=device_dist.values,
                name='设备分布',
                marker_color='#26C6DA'
            ),
            row=1, col=3
        )
        
        # 4. 页面停留时间分布
        if 'duration_seconds' in behavior.columns:
            fig.add_trace(
                go.Histogram(
                    x=behavior['duration_seconds'],
                    nbinsx=30,
                    name='停留时间',
                    marker_color='#AB47BC'
                ),
                row=2, col=1
            )
        
        # 5. 会话分析（示例）
        session_analysis = behavior.groupby('session_id').agg({
            'event_time': ['min', 'max', 'count'],
            'user_id': 'first'
        }).head(50)
        
        if not session_analysis.empty:
            session_analysis.columns = ['start_time', 'end_time', 'event_count', 'user_id']
            session_analysis['duration'] = (session_analysis['end_time'] - session_analysis['start_time']).dt.total_seconds()
            
            fig.add_trace(
                go.Scatter(
                    x=session_analysis['event_count'],
                    y=session_analysis['duration'],
                    mode='markers',
                    marker=dict(
                        size=session_analysis['event_count'] * 2,
                        color=session_analysis['event_count'],
                        colorscale='Rainbow',
                        showscale=True
                    ),
                    name='会话分析'
                ),
                row=2, col=2
            )
        
        # 6. 用户行为路径（简化版）
        # 这里使用示例数据，实际应用中需要复杂的路径分析
        sankey_labels = ['首页', '列表页', '详情页', '购物车', '支付页', '完成']
        sankey_source = [0, 0, 1, 1, 2, 2, 3, 3, 4]
        sankey_target = [1, 2, 2, 3, 3, 4, 4, 5, 5]
        sankey_value = [100, 50, 30, 20, 15, 10, 8, 5, 3]
        
        fig.add_trace(
            go.Sankey(
                node=dict(
                    pad=15,
                    thickness=20,
                    line=dict(color="black", width=0.5),
                    label=sankey_labels,
                    color="blue"
                ),
                link=dict(
                    source=sankey_source,
                    target=sankey_target,
                    value=sankey_value
                )
            ),
            row=2, col=3
        )
        
        # 更新布局
        fig.update_layout(
            title_text='用户行为分析仪表板',
            height=800,
            showlegend=False,
            template='plotly_white'
        )
        
        # 保存图表
        fig.write_html("data/analysis/behavior_dashboard.html")
        print("  ✓ 用户行为仪表板已保存: data/analysis/behavior_dashboard.html")
        
        return fig
    
    def create_refund_analysis_charts(self):
        """创建退款分析图表"""
        print("🔄 生成退款分析图表...")
        
        if self.data['refunds'].empty:
            print("  ⓘ 无退款数据，跳过生成")
            return None
        
        refunds = self.data['refunds']
        
        # 创建子图
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=(
                '退款原因分布', '退款金额分布',
                '退款时间趋势', '退款率分析'
            ),
            specs=[
                [{'type': 'pie'}, {'type': 'histogram'}],
                [{'type': 'scatter'}, {'type': 'bar'}]
            ]
        )
        
        # 1. 退款原因分布
        reason_dist = refunds['refund_reason'].value_counts()
        fig.add_trace(
            go.Pie(
                labels=reason_dist.index,
                values=reason_dist.values,
                hole=0.4,
                name='退款原因',
                marker_colors=px.colors.qualitative.Pastel
            ),
            row=1, col=1
        )
        
        # 2. 退款金额分布
        fig.add_trace(
            go.Histogram(
                x=refunds['refund_amount'],
                nbinsx=20,
                name='退款金额分布',
                marker_color='#EF5350'
            ),
            row=1, col=2
        )
        
        # 3. 退款时间趋势
        refunds['month'] = refunds['refund_date'].dt.to_period('M').astype(str)
        monthly_refunds = refunds.groupby('month').agg({
            'refund_amount': 'sum',
            'refund_id': 'count'
        }).reset_index()
        
        fig.add_trace(
            go.Scatter(
                x=monthly_refunds['month'],
                y=monthly_refunds['refund_amount'],
                mode='lines+markers',
                name='退款金额趋势',
                line=dict(color='#FF7043', width=3)
            ),
            row=2, col=1
        )
        
        # 4. 退款率分析（如果有订单数据）
        if not self.data['orders'].empty:
            # 按品类计算退款率
            orders_by_category = self.data['orders'].groupby('category').size()
            refunds_by_category = refunds.merge(
                self.data['orders'][['order_id', 'category']],
                on='order_id'
            ).groupby('category').size()
            
            refund_rate_by_category = (refunds_by_category / orders_by_category * 100).fillna(0)
            
            fig.add_trace(
                go.Bar(
                    x=refund_rate_by_category.index,
                    y=refund_rate_by_category.values,
                    name='品类退款率',
                    marker_color='#29B6F6'
                ),
                row=2, col=2
            )
        
        # 更新布局
        fig.update_layout(
            title_text='退款分析仪表板',
            height=700,
            showlegend=False,
            template='plotly_white'
        )
        
        # 保存图表
        fig.write_html("data/analysis/refund_dashboard.html")
        print("  ✓ 退款分析仪表板已保存: data/analysis/refund_dashboard.html")
        
        return fig
    
    def create_matplotlib_charts(self):
        """创建静态Matplotlib图表"""
        print("📊 生成静态分析图表...")
        
        import matplotlib.pyplot as plt
        from matplotlib.gridspec import GridSpec
        
        orders = self.data['orders']
        
        # 创建大图
        fig = plt.figure(figsize=(20, 15))
        gs = GridSpec(3, 3, figure=fig)
        
        # 1. 月度销售趋势
        ax1 = fig.add_subplot(gs[0, 0])
        monthly_sales = orders.groupby(orders['order_date'].dt.to_period('M'))['total_amount'].sum()
        ax1.plot(monthly_sales.index.astype(str), monthly_sales.values, 'o-', linewidth=2, markersize=8)
        ax1.set_title('月度销售趋势', fontsize=12, fontweight='bold')
        ax1.set_ylabel('销售额 (元)', fontsize=10)
        ax1.tick_params(axis='x', rotation=45)
        ax1.grid(True, alpha=0.3)
        
        # 2. 品类销售分布
        ax2 = fig.add_subplot(gs[0, 1])
        category_sales = orders.groupby('category')['total_amount'].sum()
        colors = plt.cm.Set3(np.linspace(0, 1, len(category_sales)))
        ax2.pie(category_sales.values, labels=category_sales.index, autopct='%1.1f%%', colors=colors)
        ax2.set_title('品类销售分布', fontsize=12, fontweight='bold')
        
        # 3. 品牌销售TOP10
        ax3 = fig.add_subplot(gs[0, 2])
        brand_sales = orders.groupby('brand')['total_amount'].sum().nlargest(10)
        ax3.barh(brand_sales.index, brand_sales.values, color=plt.cm.viridis(np.linspace(0, 1, 10)))
        ax3.set_title('品牌销售TOP10', fontsize=12, fontweight='bold')
        ax3.set_xlabel('销售额 (元)', fontsize=10)
        
        # 4. 周度销售分布
        ax4 = fig.add_subplot(gs[1, 0])
        orders['weekday'] = orders['order_date'].dt.day_name()
        weekday_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        weekday_sales = orders.groupby('weekday')['total_amount'].sum().reindex(weekday_order)
        ax4.bar(weekday_sales.index, weekday_sales.values, color='skyblue')
        ax4.set_title('周度销售分布', fontsize=12, fontweight='bold')
        ax4.set_ylabel('销售额 (元)', fontsize=10)
        ax4.tick_params(axis='x', rotation=45)
        
        # 5. 支付方式分布
        ax5 = fig.add_subplot(gs[1, 1])
        payment_dist = orders['payment_method'].value_counts()
        ax5.bar(payment_dist.index, payment_dist.values, color=plt.cm.Pastel1(range(len(payment_dist))))
        ax5.set_title('支付方式分布', fontsize=12, fontweight='bold')
        ax5.set_ylabel('订单数', fontsize=10)
        ax5.tick_params(axis='x', rotation=45)
        
        # 6. 客单价分布
        ax6 = fig.add_subplot(gs[1, 2])
        customer_spending = orders.groupby('user_id')['total_amount'].sum()
        ax6.hist(customer_spending.values, bins=30, edgecolor='black', alpha=0.7, color='lightcoral')
        ax6.set_title('客单价分布', fontsize=12, fontweight='bold')
        ax6.set_xlabel('消费金额 (元)', fontsize=10)
        ax6.set_ylabel('客户数', fontsize=10)
        ax6.grid(True, alpha=0.3)
        
        # 7. 价格与销量关系
        ax7 = fig.add_subplot(gs[2, 0])
        product_stats = orders.groupby('product_id').agg({
            'unit_price': 'mean',
            'quantity': 'sum'
        })
        ax7.scatter(product_stats['unit_price'], product_stats['quantity'], 
                   alpha=0.6, s=100, c=product_stats['unit_price'], cmap='viridis')
        ax7.set_title('价格 vs 销量', fontsize=12, fontweight='bold')
        ax7.set_xlabel('平均价格 (元)', fontsize=10)
        ax7.set_ylabel('销量', fontsize=10)
        ax7.grid(True, alpha=0.3)
        
        # 8. 折扣率分布
        ax8 = fig.add_subplot(gs[2, 1])
        ax8.hist(orders['discount_rate'], bins=20, edgecolor='black', alpha=0.7, color='lightgreen')
        ax8.set_title('折扣率分布', fontsize=12, fontweight='bold')
        ax8.set_xlabel('折扣率', fontsize=10)
        ax8.set_ylabel('订单数', fontsize=10)
        ax8.grid(True, alpha=0.3)
        
        # 9. 时间趋势（小时）
        ax9 = fig.add_subplot(gs[2, 2])
        orders['hour'] = orders['order_date'].dt.hour
        hourly_sales = orders.groupby('hour')['total_amount'].sum()
        ax9.plot(hourly_sales.index, hourly_sales.values, 'o-', linewidth=2, markersize=6, color='orange')
        ax9.set_title('小时销售趋势', fontsize=12, fontweight='bold')
        ax9.set_xlabel('小时', fontsize=10)
        ax9.set_ylabel('销售额 (元)', fontsize=10)
        ax9.grid(True, alpha=0.3)
        
        plt.suptitle('电商数据分析图表汇总', fontsize=16, fontweight='bold', y=1.02)
        plt.tight_layout()
        
        # 保存图表
        plt.savefig('data/analysis/static_analysis.png', dpi=150, bbox_inches='tight')
        plt.savefig('data/analysis/static_analysis.pdf', bbox_inches='tight')
        
        print("  ✓ 静态图表已保存:")
        print("    - data/analysis/static_analysis.png")
        print("    - data/analysis/static_analysis.pdf")
        
        return fig
    
    def generate_all_visualizations(self):
        """生成所有可视化图表"""
        print("🚀 开始生成可视化图表...")
        print("="*60)
        
        # 创建输出目录
        import os
        os.makedirs('data/analysis', exist_ok=True)
        
        # 生成各种图表
        try:
            self.create_sales_dashboard()
            self.create_customer_analysis_charts()
            self.create_product_analysis_charts()
            self.create_behavior_analysis_charts()
            self.create_refund_analysis_charts()
            self.create_matplotlib_charts()
            
            print("\n" + "="*60)
            print("✅ 所有可视化图表生成完成！")
            print("="*60)
            
            print("\n📁 生成的可视化文件:")
            print("  🌐 交互式仪表板 (HTML):")
            print("    • data/analysis/sales_dashboard.html - 销售仪表板")
            print("    • data/analysis/customer_dashboard.html - 客户分析仪表板")
            print("    • data/analysis/product_dashboard.html - 产品分析仪表板")
            print("    • data/analysis/behavior_dashboard.html - 用户行为仪表板")
            print("    • data/analysis/refund_dashboard.html - 退款分析仪表板")
            
            print("\n  🖼️ 静态图表:")
            print("    • data/analysis/static_analysis.png - 综合分析图表")
            print("    • data/analysis/static_analysis.pdf - 高质量PDF版本")
            
            print("\n💡 使用说明:")
            print("  1. 用浏览器打开HTML文件查看交互式图表")
            print("  2. 静态图表可用于报告和演示")
            print("  3. 所有图表数据基于生成的模拟数据")
            
        except Exception as e:
            print(f"\n❌ 图表生成过程中出现错误: {e}")
            import traceback
            traceback.print_exc()

def main():
    """主函数"""
    print("🎨 电商数据可视化平台")
    print("="*60)
    
    try:
        # 初始化可视化器
        visualizer = EcommerceVisualizer()
        
        # 生成所有可视化图表
        visualizer.generate_all_visualizations()
        
    except Exception as e:
        print(f"\n❌ 初始化失败: {e}")
        print("请确保已运行 data_generator.py 生成数据")

if __name__ == "__main__":
    main()