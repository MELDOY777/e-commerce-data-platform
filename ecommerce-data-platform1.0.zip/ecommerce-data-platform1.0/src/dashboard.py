# src/dashboard.py
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import json
import os

# 页面配置
st.set_page_config(
    page_title="电商数据分析仪表板",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 自定义CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1E3A8A;
        text-align: center;
        margin-bottom: 2rem;
        font-weight: bold;
    }
    .sub-header {
        font-size: 1.5rem;
        color: #3B82F6;
        margin-top: 1.5rem;
        margin-bottom: 1rem;
        font-weight: bold;
    }
    .metric-card {
        background-color: #F3F4F6;
        padding: 1.5rem;
        border-radius: 10px;
        text-align: center;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .metric-value {
        font-size: 2rem;
        font-weight: bold;
        color: #1E3A8A;
    }
    .metric-label {
        font-size: 1rem;
        color: #6B7280;
        margin-top: 0.5rem;
    }
    .stAlert {
        border-radius: 10px;
    }
</style>
""", unsafe_allow_html=True)

class EcommerceDashboard:
    def __init__(self):
        """初始化仪表板"""
        self.data_path = "data"
        self.data = self.load_data()
    
    def load_data(self):
        """加载数据 - 适配JSON格式数据"""
        data = {}
        
        try:
            # 加载现有的JSON数据文件
            data['orders'] = pd.read_json(f"{self.data_path}/processed_orders.json")
            data['users'] = pd.read_json(f"{self.data_path}/user_profiles.json")
            data['products'] = pd.read_json(f"{self.data_path}/product_catalog.json")
            
            # 生成分析报告（动态计算，因为可能没有analysis目录）
            data['report'] = self.generate_analysis_report(data)
            data['recommendations'] = self.generate_recommendations(data)
            
            # 确保日期列是datetime类型
            if 'order_date' in data['orders'].columns:
                data['orders']['order_date'] = pd.to_datetime(data['orders']['order_date'])
            if 'registration_date' in data['users'].columns:
                data['users']['registration_date'] = pd.to_datetime(data['users']['registration_date'])
                
        except FileNotFoundError as e:
            st.error(f"数据文件未找到！错误: {e}")
            st.info("请确保已运行 data_generator.py 并生成了JSON数据文件")
            st.stop()
        
        return data
    
    def generate_analysis_report(self, data):
        """根据JSON数据生成分析报告"""
        orders = data['orders']
        users = data['users']
        products = data['products']
        
        # 基本统计
        total_sales = orders['total_amount'].sum() if 'total_amount' in orders.columns else 0
        total_orders = len(orders)
        total_customers = users['user_id'].nunique() if 'user_id' in users.columns else len(users)
        avg_order_value = orders['total_amount'].mean() if 'total_amount' in orders.columns else 0
        
        # 产品分析
        product_stats = {}
        if not products.empty:
            # 简单的产品统计
            product_stats = {
                'name': '数据统计',
                '销售额': total_sales,
                '销量': total_orders
            }
        
        # 品类分析（从订单数据中提取）
        category_stats = {}
        if 'category' in orders.columns:
            category_sales = orders.groupby('category')['total_amount'].sum().to_dict()
            category_orders = orders.groupby('category').size().to_dict()
            category_avg = orders.groupby('category')['total_amount'].mean().to_dict()
            
            category_stats = {
                '销售额': category_sales,
                '订单数': category_orders,
                '平均订单额': category_avg
            }
        
        # 品牌分析
        brand_stats = {}
        if 'brand' in orders.columns:
            brand_sales = orders.groupby('brand')['total_amount'].sum().to_dict()
            brand_orders = orders.groupby('brand').size().to_dict()
            brand_avg = orders.groupby('brand')['total_amount'].mean().to_dict()
            
            brand_stats = {
                '销售额': brand_sales,
                '订单数': brand_orders,
                '平均订单额': brand_avg
            }
        
        return {
            'basic': {
                'total_sales': float(total_sales),
                'total_orders': total_orders,
                'total_customers': total_customers,
                'avg_order_value': float(avg_order_value),
                'conversion_rate': 65.2,  # 示例数据
                'active_users': len(users)
            },
            'product': {
                'category_stats': category_stats,
                'brand_stats': brand_stats,
                'product_stats': product_stats
            },
            'customer': {
                'rfm_analysis': {},
                'clv_stats': {}
            },
            'generation_time': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
    
    def generate_recommendations(self, data):
        """生成业务建议"""
        orders = data['orders']
        
        recommendations = []
        
        # 基于数据的建议
        if not orders.empty:
            # 检查销售额
            total_sales = orders['total_amount'].sum() if 'total_amount' in orders.columns else 0
            if total_sales < 100000:
                recommendations.append({
                    'category': '销售提升',
                    'suggestion': '提升整体销售额',
                    'action': '考虑开展促销活动或优化产品组合',
                    'priority': '高'
                })
            
            # 检查订单数量
            if len(orders) < 100:
                recommendations.append({
                    'category': '订单增长',
                    'suggestion': '增加订单数量',
                    'action': '优化购买流程，提高转化率',
                    'priority': '中'
                })
        
        # 默认建议
        if not recommendations:
            recommendations.append({
                'category': '数据监控',
                'suggestion': '持续监控数据',
                'action': '定期分析销售数据和用户行为',
                'priority': '中'
            })
        
        return recommendations
    
    def display_header(self):
        """显示页头"""
        st.markdown('<h1 class="main-header">📊 电商数据分析仪表板</h1>', unsafe_allow_html=True)
        
        # 日期信息
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            today = datetime.now().strftime("%Y年%m月%d日")
            report_time = self.data['report']['generation_time']
            st.info(f"📅 数据更新时间: {report_time} | 当前时间: {today}")
    
    def display_kpi_metrics(self):
        """显示KPI指标"""
        st.markdown('<h2 class="sub-header">📈 关键业务指标</h2>', unsafe_allow_html=True)
        
        report = self.data['report']['basic']
        
        # 创建指标卡片
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">¥{report['total_sales']:,.0f}</div>
                <div class="metric-label">总销售额</div>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{report['total_orders']:,}</div>
                <div class="metric-label">总订单数</div>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{report['total_customers']:,}</div>
                <div class="metric-label">消费客户数</div>
            </div>
            """, unsafe_allow_html=True)
        
        with col4:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">¥{report['avg_order_value']:,.0f}</div>
                <div class="metric-label">平均订单额</div>
            </div>
            """, unsafe_allow_html=True)
        
        # 第二行指标
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            conversion_rate = report['conversion_rate']
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{conversion_rate:.1f}%</div>
                <div class="metric-label">购买转化率</div>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            active_users = report['active_users']
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{active_users:,}</div>
                <div class="metric-label">30天活跃用户</div>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            clv = 0  # 暂时设为0
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">¥{clv:,.0f}</div>
                <div class="metric-label">平均客户价值</div>
            </div>
            """, unsafe_allow_html=True)
        
        with col4:
            refund_rate = 0  # 暂时设为0
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{refund_rate:.2f}%</div>
                <div class="metric-label">整体退款率</div>
            </div>
            """, unsafe_allow_html=True)
    
    def display_sales_analysis(self):
        """显示销售分析"""
        st.markdown('<h2 class="sub-header">💰 销售分析</h2>', unsafe_allow_html=True)
        
        tab1, tab2, tab3 = st.tabs(["📅 时间趋势", "📦 品类分析", "🏷️ 品牌分析"])
        
        with tab1:
            orders = self.data['orders']
            
            if not orders.empty and 'order_date' in orders.columns:
                col1, col2 = st.columns([2, 1])
                
                with col1:
                    # 月度销售趋势
                    orders['order_date'] = pd.to_datetime(orders['order_date'])
                    monthly_sales = orders.groupby(orders['order_date'].dt.to_period('M'))['total_amount'].sum()
                    
                    fig = go.Figure()
                    fig.add_trace(go.Scatter(
                        x=monthly_sales.index.astype(str),
                        y=monthly_sales.values,
                        mode='lines+markers',
                        name='月度销售额',
                        line=dict(color='#3B82F6', width=3),
                        fill='tozeroy',
                        fillcolor='rgba(59, 130, 246, 0.1)'
                    ))
                    
                    fig.update_layout(
                        title='月度销售趋势',
                        xaxis_title='月份',
                        yaxis_title='销售额 (元)',
                        template='plotly_white',
                        height=400
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                
                with col2:
                    # 周度销售
                    orders['weekday'] = orders['order_date'].dt.day_name()
                    weekday_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
                    weekday_sales = orders.groupby('weekday')['total_amount'].sum().reindex(weekday_order)
                    
                    fig = go.Figure()
                    fig.add_trace(go.Bar(
                        x=weekday_sales.index,
                        y=weekday_sales.values,
                        marker_color='#10B981'
                    ))
                    
                    fig.update_layout(
                        title='周度销售分布',
                        xaxis_title='星期',
                        yaxis_title='销售额 (元)',
                        template='plotly_white',
                        height=400
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("当前数据中没有时间信息")
        
        with tab2:
            # 品类分析
            category_stats = self.data['report']['product']['category_stats']
            
            if category_stats and '销售额' in category_stats and category_stats['销售额']:
                col1, col2 = st.columns([1, 1])
                
                with col1:
                    # 品类销售额占比
                    categories = list(category_stats['销售额'].keys())
                    sales_values = list(category_stats['销售额'].values())
                    
                    fig = go.Figure(data=[go.Pie(
                        labels=categories,
                        values=sales_values,
                        hole=0.3,
                        marker_colors=px.colors.qualitative.Set3
                    )])
                    
                    fig.update_layout(
                        title='品类销售额占比',
                        template='plotly_white',
                        height=400
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                
                with col2:
                    # 品类销售表格
                    st.markdown("##### 品类详细数据")
                    category_df = pd.DataFrame({
                        '品类': categories,
                        '销售额': [f'¥{v:,.0f}' for v in sales_values],
                        '订单数': [int(category_stats['订单数'].get(cat, 0)) for cat in categories],
                        '平均订单额': [f'¥{category_stats["平均订单额"].get(cat, 0):,.0f}' for cat in categories]
                    })
                    
                    st.dataframe(category_df, use_container_width=True, hide_index=True)
            else:
                st.info("当前数据中没有品类信息")
        
        with tab3:
            # 品牌分析
            brand_stats = self.data['report']['product']['brand_stats']
            
            if brand_stats and '销售额' in brand_stats and brand_stats['销售额']:
                # 品牌销售额TOP10
                brands = list(brand_stats['销售额'].keys())[:10]
                brand_sales = list(brand_stats['销售额'].values())[:10]
                
                fig = go.Figure()
                fig.add_trace(go.Bar(
                    x=brand_sales,
                    y=brands,
                    orientation='h',
                    marker_color=px.colors.sequential.Blues
                ))
                
                fig.update_layout(
                    title='品牌销售额TOP10',
                    xaxis_title='销售额 (元)',
                    yaxis_title='品牌',
                    template='plotly_white',
                    height=500
                )
                
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("当前数据中没有品牌信息")
    
    def display_customer_analysis(self):
        """显示客户分析"""
        st.markdown('<h2 class="sub-header">👥 客户分析</h2>', unsafe_allow_html=True)
        
        tab1, tab2 = st.tabs(["👤 客户画像", "📊 客户分布"])
        
        with tab1:
            users = self.data['users']
            
            if not users.empty:
                col1, col2 = st.columns([1, 1])
                
                with col1:
                    # 年龄分布
                    if 'age' in users.columns:
                        fig = go.Figure()
                        fig.add_trace(go.Histogram(
                            x=users['age'],
                            nbinsx=10,
                            marker_color='#3B82F6'
                        ))
                        
                        fig.update_layout(
                            title='客户年龄分布',
                            xaxis_title='年龄',
                            yaxis_title='客户数',
                            template='plotly_white',
                            height=400
                        )
                        
                        st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.info("当前数据中没有年龄信息")
                
                with col2:
                    # 会员等级分布
                    if 'membership_level' in users.columns:
                        membership_dist = users['membership_level'].value_counts()
                        
                        fig = go.Figure()
                        fig.add_trace(go.Pie(
                            labels=membership_dist.index,
                            values=membership_dist.values,
                            hole=0.3,
                            marker_colors=px.colors.sequential.RdBu
                        ))
                        
                        fig.update_layout(
                            title='会员等级分布',
                            template='plotly_white',
                            height=400
                        )
                        
                        st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.info("当前数据中没有会员等级信息")
            else:
                st.info("当前没有客户数据")
        
        with tab2:
            # 客户地理分布（如果有）
            orders = self.data['orders']
            if 'shipping_city' in orders.columns:
                city_counts = orders['shipping_city'].value_counts().head(15)
                
                fig = go.Figure()
                fig.add_trace(go.Bar(
                    x=city_counts.values,
                    y=city_counts.index,
                    orientation='h',
                    marker_color='#8B5CF6'
                ))
                
                fig.update_layout(
                    title='客户城市分布TOP15',
                    xaxis_title='订单数量',
                    yaxis_title='城市',
                    template='plotly_white',
                    height=500
                )
                
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("当前数据中没有地域信息")
    
    def display_product_analysis(self):
        """显示产品分析"""
        st.markdown('<h2 class="sub-header">📦 产品分析</h2>', unsafe_allow_html=True)
        
        tab1, tab2 = st.tabs(["📋 产品列表", "💰 价格分析"])
        
        with tab1:
            # 显示产品列表
            products = self.data['products']
            
            if not products.empty:
                st.markdown("##### 产品目录")
                
                # 显示关键信息
                display_cols = []
                for col in ['id', 'name', 'category', 'brand', 'price']:
                    if col in products.columns:
                        display_cols.append(col)
                
                if display_cols:
                    display_df = products[display_cols].copy()
                    if 'price' in display_df.columns:
                        display_df['price'] = display_df['price'].apply(lambda x: f'¥{x:,.0f}' if pd.notnull(x) else '')
                    st.dataframe(display_df, use_container_width=True, height=400)
                else:
                    st.info("产品数据中没有可显示的列")
            else:
                st.info("当前没有产品数据")
        
        with tab2:
            # 价格分析
            orders = self.data['orders']
            
            if not orders.empty:
                col1, col2 = st.columns([1, 1])
                
                with col1:
                    # 价格分布
                    if 'unit_price' in orders.columns:
                        fig = go.Figure()
                        fig.add_trace(go.Histogram(
                            x=orders['unit_price'],
                            nbinsx=30,
                            marker_color='#FF6B6B'
                        ))
                        
                        fig.update_layout(
                            title='产品价格分布',
                            xaxis_title='价格 (元)',
                            yaxis_title='订单数',
                            template='plotly_white',
                            height=400
                        )
                        
                        st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.info("当前数据中没有单价信息")
                
                with col2:
                    # 订单金额分布
                    if 'total_amount' in orders.columns:
                        fig = go.Figure()
                        fig.add_trace(go.Box(
                            y=orders['total_amount'],
                            name='订单金额',
                            marker_color='#4ECDC4'
                        ))
                        
                        fig.update_layout(
                            title='订单金额分布',
                            yaxis_title='金额 (元)',
                            template='plotly_white',
                            height=400
                        )
                        
                        st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.info("当前数据中没有订单金额信息")
            else:
                st.info("当前没有订单数据")
    
    def display_refund_analysis(self):
        """显示退款分析"""
        st.markdown('<h2 class="sub-header">🔄 退款分析</h2>', unsafe_allow_html=True)
        st.info("当前数据中没有退款信息")
    
    def display_recommendations(self):
        """显示业务建议"""
        st.markdown('<h2 class="sub-header">💡 业务优化建议</h2>', unsafe_allow_html=True)
        
        recommendations = self.data['recommendations']
        
        if not recommendations:
            st.info("暂无业务建议")
            return
        
        # 按优先级排序
        priority_order = {'紧急': 1, '高': 2, '中': 3, '低': 4}
        recommendations.sort(key=lambda x: priority_order.get(x.get('priority', '中'), 3))
        
        for i, rec in enumerate(recommendations, 1):
            # 根据优先级设置颜色
            priority_color = {
                '紧急': '#EF4444',
                '高': '#F59E0B',
                '中': '#10B981',
                '低': '#6B7280'
            }.get(rec.get('priority', '中'), '#6B7280')
            
            with st.container():
                st.markdown(f"""
                <div style="
                    background-color: #F9FAFB;
                    padding: 1rem;
                    border-radius: 10px;
                    border-left: 5px solid {priority_color};
                    margin-bottom: 1rem;
                ">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <h4 style="margin: 0; color: {priority_color};">{rec['category']} - {rec['suggestion']}</h4>
                        <span style="background-color: {priority_color}; color: white; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.875rem;">
                            {rec['priority']}优先级
                        </span>
                    </div>
                    <p style="margin-top: 0.5rem; margin-bottom: 0; color: #4B5563;">
                        📋 <strong>建议行动:</strong> {rec['action']}
                    </p>
                </div>
                """, unsafe_allow_html=True)
    
    def display_sidebar(self):
        """显示侧边栏"""
        with st.sidebar:
            st.image("https://cdn-icons-png.flaticon.com/512/3082/3082383.png", width=100)
            st.markdown("## 📊 导航菜单")
            
            # 数据更新时间
            update_time = self.data['report']['generation_time']
            st.caption(f"📅 数据更新时间: {update_time}")
            
            st.divider()
            
            # 页面导航
            page = st.radio(
                "选择分析页面",
                ["📈 仪表板总览", "💰 销售分析", "👥 客户分析", 
                 "📦 产品分析", "💡 业务建议"]
            )
            
            st.divider()
            
            # 数据筛选器
            st.markdown("### 🔍 数据筛选")
            
            # 时间范围筛选
            orders = self.data['orders']
            if not orders.empty and 'order_date' in orders.columns:
                orders['order_date'] = pd.to_datetime(orders['order_date'])
                min_date = orders['order_date'].min()
                max_date = orders['order_date'].max()
                
                date_range = st.date_input(
                    "选择时间范围",
                    value=[min_date.date(), max_date.date()],
                    min_value=min_date.date(),
                    max_value=max_date.date()
                )
            
            # 品类筛选
            if not orders.empty and 'category' in orders.columns:
                categories = orders['category'].unique()
                selected_categories = st.multiselect(
                    "选择品类",
                    options=categories,
                    default=categories
                )
            
            # 品牌筛选
            if not orders.empty and 'brand' in orders.columns:
                brands = orders['brand'].unique()
                selected_brands = st.multiselect(
                    "选择品牌",
                    options=brands,
                    default=brands
                )
            
            st.divider()
            
            # 快捷操作
            st.markdown("### ⚡ 快捷操作")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("🔄 刷新数据", use_container_width=True):
                    st.rerun()
            
            with col2:
                if st.button("📥 导出报告", use_container_width=True):
                    st.info("导出功能开发中...")
            
            st.divider()
            
            # 系统信息
            st.markdown("### ℹ️ 系统信息")
            st.caption(f"用户数: {len(self.data['users'])}")
            st.caption(f"订单数: {len(self.data['orders'])}")
            st.caption(f"产品数: {len(self.data['products'])}")
            
            return page
    
    def run(self):
        """运行仪表板"""
        # 显示侧边栏并获取当前页面
        current_page = self.display_sidebar()
        
        # 显示页头
        self.display_header()
        
        # 显示KPI指标
        self.display_kpi_metrics()
        
        # 根据选择的页面显示内容
        if current_page == "📈 仪表板总览":
            st.markdown('<h2 class="sub-header">📊 综合分析概览</h2>', unsafe_allow_html=True)
            
            # 显示所有主要分析模块
            self.display_sales_analysis()
            self.display_customer_analysis()
            self.display_product_analysis()
            self.display_recommendations()
            
        elif current_page == "💰 销售分析":
            self.display_sales_analysis()
            
        elif current_page == "👥 客户分析":
            self.display_customer_analysis()
            
        elif current_page == "📦 产品分析":
            self.display_product_analysis()
            
        elif current_page == "💡 业务建议":
            self.display_recommendations()

def main():
    """主函数"""
    st.markdown("""
    <style>
    .stApp {
        max-width: 1400px;
        margin: 0 auto;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # 初始化并运行仪表板
    try:
        dashboard = EcommerceDashboard()
        dashboard.run()
    except Exception as e:
        st.error(f"仪表板运行出错: {str(e)}")
        st.info("请确保已运行 data_generator.py 生成JSON数据")

if __name__ == "__main__":
    main()