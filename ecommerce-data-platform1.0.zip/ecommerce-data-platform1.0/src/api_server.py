# src/api_server.py - 统一数据API
from flask import Flask, jsonify, request
from flask_cors import CORS
import pandas as pd
import json
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)  # 允许跨域访问

# 数据加载函数
def load_orders():
    """加载订单数据"""
    return pd.read_json('data/processed_orders.json')

def load_users():
    """加载用户数据"""
    return pd.read_json('data/user_profiles.json')

def load_products():
    """加载产品数据"""
    return pd.read_json('data/product_catalog.json')

@app.route('/')
def home():
    """首页"""
    return jsonify({
        'message': '电商数据API服务',
        'endpoints': {
            '/api/data/basic': '基础数据统计',
            '/api/data/orders': '订单数据',
            '/api/data/users': '用户数据',
            '/api/data/products': '产品数据',
            '/api/viz/sales-trend': '销售趋势图表数据',
            '/api/viz/category': '品类分布图表数据'
        },
        'status': 'running'
    })

@app.route('/api/data/basic')
def get_basic_stats():
    """获取基础统计数据"""
    try:
        orders = load_orders()
        users = load_users()
        
        stats = {
            'total_sales': float(orders['total_amount'].sum()),
            'total_orders': len(orders),
            'total_customers': users['user_id'].nunique(),
            'avg_order_value': float(orders['total_amount'].mean()),
            'conversion_rate': 65.2,
            'active_users': len(users),
            'success': True
        }
        return jsonify(stats)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/data/orders')
def get_orders():
    """获取订单数据"""
    try:
        orders = load_orders()
        # 支持分页
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 50))
        
        start = (page - 1) * per_page
        end = start + per_page
        
        return jsonify({
            'success': True,
            'data': orders.iloc[start:end].to_dict(orient='records'),
            'total': len(orders),
            'page': page,
            'per_page': per_page
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/data/users')
def get_users():
    """获取用户数据"""
    try:
        users = load_users()
        return jsonify({
            'success': True,
            'data': users.to_dict(orient='records'),
            'total': len(users)
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/data/products')
def get_products():
    """获取产品数据"""
    try:
        products = load_products()
        return jsonify({
            'success': True,
            'data': products.to_dict(orient='records'),
            'total': len(products)
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/viz/sales-trend')
def get_sales_trend():
    """获取销售趋势图表数据"""
    try:
        orders = load_orders()
        orders['order_date'] = pd.to_datetime(orders['order_date'])
        
        # 按时间聚合（支持不同周期）
        period = request.args.get('period', 'month')  # month/week/day
        if period == 'month':
            trend = orders.groupby(orders['order_date'].dt.to_period('M'))['total_amount'].sum()
            x_data = trend.index.astype(str).tolist()
        elif period == 'week':
            trend = orders.groupby(orders['order_date'].dt.isocalendar().week)['total_amount'].sum()
            x_data = [f'第{week}周' for week in trend.index]
        else:  # day
            trend = orders.groupby(orders['order_date'].dt.date)['total_amount'].sum()
            x_data = [d.strftime('%Y-%m-%d') for d in trend.index]
        
        # 构建 Plotly 图表数据
        chart_data = {
            'data': [{
                'x': x_data,
                'y': trend.values.tolist(),
                'type': 'scatter',
                'mode': 'lines+markers',
                'name': '销售额',
                'line': {'color': '#3B82F6', 'width': 3},
                'fill': 'tozeroy',
                'fillcolor': 'rgba(59, 130, 246, 0.1)'
            }],
            'layout': {
                'title': '销售趋势分析',
                'xaxis': {'title': '时间'},
                'yaxis': {'title': '销售额 (元)'},
                'template': 'plotly_white',
                'height': 500
            }
        }
        
        return jsonify({'success': True, 'plotly_fig': chart_data})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/viz/category')
def get_category_distribution():
    """获取品类分布图表数据"""
    try:
        orders = load_orders()
        if 'category' not in orders.columns:
            return jsonify({'success': False, 'error': '数据中没有品类信息'})
        
        top_n = int(request.args.get('top_n', 8))
        category_sales = orders.groupby('category')['total_amount'].sum()
        top_categories = category_sales.nlargest(top_n)
        
        # 构建饼图数据
        chart_data = {
            'data': [{
                'labels': top_categories.index.tolist(),
                'values': top_categories.values.tolist(),
                'type': 'pie',
                'hole': 0.3,
                'marker': {'colors': [
                    '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', 
                    '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F'
                ]}
            }],
            'layout': {
                'title': '品类销售额分布',
                'template': 'plotly_white',
                'height': 500
            }
        }
        
        return jsonify({'success': True, 'plotly_fig': chart_data})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/status')
def get_status():
    """获取系统状态"""
    files = {
        'orders': 'data/processed_orders.json',
        'users': 'data/user_profiles.json',
        'products': 'data/product_catalog.json'
    }
    
    status = {}
    for name, path in files.items():
        if os.path.exists(path):
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    status[name] = {
                        'exists': True,
                        'count': len(data) if isinstance(data, list) else 'object',
                        'size': f"{os.path.getsize(path) / 1024:.1f} KB"
                    }
            except:
                status[name] = {'exists': True, 'error': '读取失败'}
        else:
            status[name] = {'exists': False}
    
    return jsonify({
        'success': True,
        'status': status,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000, host='0.0.0.0')