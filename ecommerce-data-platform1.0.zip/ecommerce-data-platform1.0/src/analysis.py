# src/analysis.py
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import json
import warnings
import os

plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")

class EcommerceAnalyzer:
    def __init__(self, data_path="data"):
        """初始化数据分析器"""
        self.data_path = data_path
        self.data = self.load_data()
        
    def load_data(self):
        """加载所有数据"""
        print("📂 加载数据...")
        data = {}
        
        try:
            # 检查目录是否存在
            if not os.path.exists(self.data_path):
                print(f"❌ 数据目录 '{self.data_path}' 不存在")
                print("请先运行 data_generator.py 生成数据")
                raise FileNotFoundError(f"数据目录 '{self.data_path}' 不存在")
            
            # 加载用户数据
            users_path = f"{self.data_path}/raw/users.csv"
            if os.path.exists(users_path):
                data['users'] = pd.read_csv(users_path, parse_dates=['registration_date'])
                print(f"  ✓ 用户数据: {len(data['users'])} 条")
            else:
                print(f"  ❌ 用户数据文件不存在: {users_path}")
                data['users'] = pd.DataFrame()
            
            # 加载订单数据
            orders_path = f"{self.data_path}/raw/orders.csv"
            if os.path.exists(orders_path):
                data['orders'] = pd.read_csv(orders_path, parse_dates=['order_date'])
                print(f"  ✓ 订单数据: {len(data['orders'])} 条")
            else:
                print(f"  ❌ 订单数据文件不存在: {orders_path}")
                raise FileNotFoundError(f"订单数据文件不存在: {orders_path}")
            
            # 加载产品数据
            products_path = f"{self.data_path}/raw/products.csv"
            if os.path.exists(products_path):
                data['products'] = pd.read_csv(products_path)
                print(f"  ✓ 产品数据: {len(data['products'])} 条")
            else:
                print(f"  ❌ 产品数据文件不存在: {products_path}")
                data['products'] = pd.DataFrame()
            
            # 加载用户行为数据
            behavior_path = f"{self.data_path}/raw/user_behavior.csv"
            if os.path.exists(behavior_path):
                data['behavior'] = pd.read_csv(behavior_path, parse_dates=['event_time'])
                print(f"  ✓ 用户行为: {len(data['behavior'])} 条")
            else:
                print(f"  ⓘ 用户行为数据文件不存在: {behavior_path}")
                data['behavior'] = pd.DataFrame()
            
            # 加载退款数据（如果有）
            refunds_path = f"{self.data_path}/raw/refunds.csv"
            if os.path.exists(refunds_path):
                data['refunds'] = pd.read_csv(refunds_path, parse_dates=['refund_date'])
                print(f"  ✓ 退款数据: {len(data['refunds'])} 条")
            else:
                data['refunds'] = pd.DataFrame()
                print(f"  ⓘ 无退款数据")
            
            # 加载用户偏好数据
            preferences_path = f"{self.data_path}/processed/user_preferences.csv"
            if os.path.exists(preferences_path):
                data['preferences'] = pd.read_csv(preferences_path)
                print(f"  ✓ 用户偏好: {len(data['preferences'])} 条")
            else:
                data['preferences'] = pd.DataFrame()
                
        except Exception as e:
            print(f"❌ 数据加载失败: {e}")
            print("请先运行 data_generator.py 生成数据")
            raise
        
        return data
    
    def basic_statistics(self):
        """基本统计分析"""
        print("\n" + "="*60)
        print("📊 基本统计分析")
        print("="*60)
        
        orders = self.data['orders']
        users = self.data['users']
        
        # 总体统计
        total_sales = float(orders['total_amount'].sum())
        total_orders = int(len(orders))
        total_customers = int(orders['user_id'].nunique())
        avg_order_value = float(orders['total_amount'].mean())
        
        print(f"💰 总销售额: ¥{total_sales:,.2f}")
        print(f"📦 总订单数: {total_orders:,} 笔")
        print(f"👥 消费客户数: {total_customers:,} 人")
        print(f"📊 平均订单额: ¥{avg_order_value:,.2f}")
        if total_customers > 0:
            customer_value = total_sales / total_customers
            print(f"🏆 客单价: ¥{customer_value:,.2f}")
        else:
            customer_value = 0
            print(f"🏆 客单价: ¥0.00")
        
        # 用户统计
        total_users = len(users) if not users.empty else 0
        if total_users > 0:
            conversion_rate = (total_customers / total_users) * 100
            print(f"\n👤 用户总数: {total_users:,} 人")
            print(f"🔄 购买转化率: {conversion_rate:.1f}%")
        else:
            conversion_rate = 0
            print(f"\n👤 用户总数: 0 人")
            print(f"🔄 购买转化率: 0.0%")
        
        # 活跃用户分析
        if not orders.empty:
            active_threshold = datetime.now() - timedelta(days=30)
            active_users = int(orders[orders['order_date'] > active_threshold]['user_id'].nunique())
            print(f"🔥 30天活跃用户: {active_users:,} 人")
            if total_users > 0:
                user_activity = active_users / total_users * 100
                print(f"📈 用户活跃度: {user_activity:.1f}%")
            else:
                user_activity = 0
                print(f"📈 用户活跃度: 0.0%")
        else:
            active_users = 0
            user_activity = 0
        
        return {
            'total_sales': total_sales,
            'total_orders': total_orders,
            'total_customers': total_customers,
            'avg_order_value': avg_order_value,
            'customer_value': customer_value,
            'conversion_rate': conversion_rate,
            'active_users': active_users,
            'user_activity': user_activity
        }
    
    def sales_analysis(self):
        """销售分析 - 返回可序列化的数据"""
        print("\n" + "="*60)
        print("💰 销售深度分析")
        print("="*60)
        
        orders = self.data['orders']
        
        if orders.empty:
            print("❌ 无订单数据")
            return {}
        
        # 月度销售趋势
        orders['order_month'] = orders['order_date'].dt.strftime('%Y-%m')
        monthly_sales = orders.groupby('order_month')['total_amount'].sum()
        
        print("📅 月度销售趋势:")
        monthly_data = {}
        for month, sales in monthly_sales.items():
            print(f"  {month}: ¥{sales:,.2f}")
            monthly_data[month] = float(sales)
        
        # 周度分析
        orders['order_weekday'] = orders['order_date'].dt.day_name()
        weekday_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        
        weekday_data = {}
        print("\n📆 周度销售分析:")
        for day in weekday_order:
            day_sales = orders[orders['order_weekday'] == day]['total_amount'].sum()
            day_count = len(orders[orders['order_weekday'] == day])
            print(f"  {day}: ¥{day_sales:,.2f} ({day_count} 笔)")
            weekday_data[day] = {
                'sales': float(day_sales),
                'count': int(day_count)
            }
        
        # 小时分析
        orders['order_hour'] = orders['order_date'].dt.hour
        hourly_data = {}
        print("\n⏰ 小时销售分析:")
        for hour in range(24):
            hour_sales = orders[orders['order_hour'] == hour]['total_amount'].sum()
            hour_count = len(orders[orders['order_hour'] == hour])
            hourly_data[hour] = {
                'sales': float(hour_sales),
                'count': int(hour_count)
            }
            if hour_count > 0:
                print(f"  {hour:02d}:00 - ¥{hour_sales:,.2f} ({hour_count} 笔)")
        
        return {
            'monthly_sales': monthly_data,
            'weekday_sales': weekday_data,
            'hourly_sales': hourly_data
        }
    
    def product_analysis(self):
        """产品分析 - 返回可序列化的数据"""
        print("\n" + "="*60)
        print("📦 产品分析")
        print("="*60)
        
        orders = self.data['orders']
        products = self.data['products']
        
        if orders.empty:
            print("❌ 无订单数据")
            return {}
        
        # 品类分析
        category_stats = orders.groupby('category').agg({
            'total_amount': 'sum',
            'order_id': 'count'
        }).rename(columns={'total_amount': 'sales', 'order_id': 'count'})
        
        category_data = {}
        total_sales = category_stats['sales'].sum()
        
        print("📊 品类表现:")
        for category, row in category_stats.iterrows():
            sales_share = (row['sales'] / total_sales * 100) if total_sales > 0 else 0
            print(f"  {category}: ¥{row['sales']:,.2f} ({sales_share:.1f}%) - {int(row['count'])} 笔")
            category_data[category] = {
                'sales': float(row['sales']),
                'count': int(row['count']),
                'share': float(sales_share)
            }
        
        # 品牌分析
        brand_stats = orders.groupby('brand').agg({
            'total_amount': 'sum',
            'order_id': 'count'
        }).rename(columns={'total_amount': 'sales', 'order_id': 'count'})
        brand_stats = brand_stats.sort_values('sales', ascending=False)
        
        brand_data = {}
        print("\n🏷️ 品牌表现TOP 5:")
        for idx, (brand, row) in enumerate(brand_stats.head(5).iterrows(), 1):
            print(f"  {idx}. {brand}: ¥{row['sales']:,.2f} ({int(row['count'])} 笔订单)")
            brand_data[brand] = {
                'sales': float(row['sales']),
                'count': int(row['count']),
                'rank': idx
            }
        
        # 热销产品TOP 10
        product_stats = orders.groupby('product_id').agg({
            'total_amount': 'sum',
            'quantity': 'sum',
            'order_id': 'count'
        }).rename(columns={'total_amount': 'sales', 'order_id': 'count'})
        product_stats = product_stats.sort_values('sales', ascending=False)
        
        top_products_data = {}
        print("\n🏆 热销产品TOP 10:")
        for idx, (product_id, row) in enumerate(product_stats.head(10).iterrows(), 1):
            product_name = f"产品{product_id}"
            if not products.empty and product_id in products['id'].values:
                product_name = products[products['id'] == product_id]['name'].iloc[0]
            
            print(f"  {idx:2d}. {product_name}")
            print(f"      销售额: ¥{row['sales']:,.2f} | 销量: {int(row['count'])} 笔")
            print(f"      销售数量: {int(row['quantity'])} 个")
            
            top_products_data[product_id] = {
                'name': product_name,
                'sales': float(row['sales']),
                'count': int(row['count']),
                'quantity': int(row['quantity']),
                'rank': idx
            }
        
        return {
            'category_stats': category_data,
            'brand_stats': brand_data,
            'top_products': top_products_data
        }
    
    def customer_analysis(self):
        """客户分析 - 返回可序列化的数据"""
        print("\n" + "="*60)
        print("👥 客户分析")
        print("="*60)
        
        orders = self.data['orders']
        users = self.data['users']
        
        if orders.empty:
            print("❌ 无订单数据")
            return {}
        
        # 客户消费统计
        customer_stats = orders.groupby('user_id').agg({
            'total_amount': 'sum',
            'order_id': 'count',
            'order_date': 'max'
        }).rename(columns={'total_amount': 'total_spent', 'order_id': 'order_count'})
        
        # 计算RFM
        analysis_date = orders['order_date'].max()
        customer_stats['recency'] = (analysis_date - customer_stats['order_date']).dt.days
        customer_stats.drop('order_date', axis=1, inplace=True)
        
        # 客户分段
        segments = {
            'vip': len(customer_stats[customer_stats['total_spent'] > 10000]),
            'high_value': len(customer_stats[(customer_stats['total_spent'] > 5000) & (customer_stats['total_spent'] <= 10000)]),
            'medium_value': len(customer_stats[(customer_stats['total_spent'] > 1000) & (customer_stats['total_spent'] <= 5000)]),
            'low_value': len(customer_stats[customer_stats['total_spent'] <= 1000])
        }
        
        print("🎯 客户价值分段:")
        print(f"  VIP客户 (>¥10,000): {segments['vip']} 人")
        print(f"  高价值客户 (¥5,000-10,000): {segments['high_value']} 人")
        print(f"  中价值客户 (¥1,000-5,000): {segments['medium_value']} 人")
        print(f"  低价值客户 (<¥1,000): {segments['low_value']} 人")
        
        # 会员等级分布
        membership_data = {}
        if not users.empty and 'membership_level' in users.columns:
            membership_dist = users['membership_level'].value_counts()
            print(f"\n🏅 会员等级分布:")
            for level, count in membership_dist.items():
                percentage = (count / len(users)) * 100
                print(f"  {level}: {count} 人 ({percentage:.1f}%)")
                membership_data[level] = {
                    'count': int(count),
                    'percentage': float(percentage)
                }
        
        # 客户生命周期价值 (CLV)
        if len(customer_stats) > 0:
            avg_clv = float(customer_stats['total_spent'].mean())
            median_clv = float(customer_stats['total_spent'].median())
            max_clv = float(customer_stats['total_spent'].max())
            
            print(f"\n💎 客户生命周期价值:")
            print(f"  平均CLV: ¥{avg_clv:,.2f}")
            print(f"  中位数CLV: ¥{median_clv:,.2f}")
            print(f"  最高CLV: ¥{max_clv:,.2f}")
        else:
            avg_clv = median_clv = max_clv = 0
        
        return {
            'customer_segments': segments,
            'membership_distribution': membership_data,
            'clv_stats': {
                'avg_clv': avg_clv,
                'median_clv': median_clv,
                'max_clv': max_clv
            },
            'total_customers': int(len(customer_stats))
        }
    
    def user_behavior_analysis(self):
        """用户行为分析 - 返回可序列化的数据"""
        print("\n" + "="*60)
        print("🖱️ 用户行为分析")
        print("="*60)
        
        behavior = self.data['behavior']
        
        if behavior.empty:
            print("❌ 无用户行为数据")
            return {}
        
        # 行为类型分析
        behavior_counts = behavior['behavior_type'].value_counts()
        behavior_data = {}
        
        print("📊 行为类型分布:")
        for behavior_type, count in behavior_counts.items():
            percentage = (count / len(behavior)) * 100
            print(f"  {behavior_type}: {count:,} 次 ({percentage:.1f}%)")
            behavior_data[behavior_type] = {
                'count': int(count),
                'percentage': float(percentage)
            }
        
        # 转化漏斗分析
        total_views = len(behavior[behavior['behavior_type'] == 'view']) if 'view' in behavior['behavior_type'].values else 0
        total_clicks = len(behavior[behavior['behavior_type'] == 'click']) if 'click' in behavior['behavior_type'].values else 0
        total_carts = len(behavior[behavior['behavior_type'] == 'add_to_cart']) if 'add_to_cart' in behavior['behavior_type'].values else 0
        unique_purchasers = self.data['orders']['user_id'].nunique() if not self.data['orders'].empty else 0
        
        print("\n🔄 用户行为转化漏斗:")
        print(f"  浏览 (View): {total_views:,} 次")
        print(f"  点击 (Click): {total_clicks:,} 次")
        print(f"  加购 (Add to Cart): {total_carts:,} 次")
        print(f"  购买 (Purchase): {unique_purchasers:,} 人")
        
        # 计算转化率
        conversion_rates = {}
        if total_views > 0:
            conversion_rates['view_to_click'] = float(total_clicks / total_views * 100)
            if total_clicks > 0:
                conversion_rates['click_to_cart'] = float(total_carts / total_clicks * 100)
            if total_carts > 0:
                conversion_rates['cart_to_purchase'] = float(unique_purchasers / total_carts * 100)
        
        if conversion_rates:
            print(f"\n📈 转化率:")
            for stage, rate in conversion_rates.items():
                if rate > 0:
                    print(f"  {stage}: {rate:.2f}%")
        
        # 热门产品浏览
        popular_products = {}
        if 'view' in behavior['behavior_type'].values:
            product_views = behavior[behavior['behavior_type'] == 'view'].groupby('product_id').size()
            top_viewed = product_views.nlargest(5)
            
            print("\n🔥 最受欢迎产品 (浏览TOP 5):")
            for idx, (product_id, views) in enumerate(top_viewed.items(), 1):
                product_name = f"产品{product_id}"
                if not self.data['products'].empty:
                    product_info = self.data['products'][self.data['products']['id'] == product_id]['name'].values
                    if len(product_info) > 0:
                        product_name = product_info[0]
                print(f"  {idx}. {product_name}: {views:,} 次浏览")
                popular_products[product_id] = {
                    'name': product_name,
                    'views': int(views),
                    'rank': idx
                }
        
        return {
            'behavior_distribution': behavior_data,
            'conversion_funnel': {
                'views': int(total_views),
                'clicks': int(total_clicks),
                'carts': int(total_carts),
                'purchases': int(unique_purchasers)
            },
            'conversion_rates': conversion_rates,
            'popular_products': popular_products
        }
    
    def payment_analysis(self):
        """支付分析 - 返回可序列化的数据"""
        print("\n" + "="*60)
        print("💳 支付分析")
        print("="*60)
        
        orders = self.data['orders']
        
        if orders.empty:
            print("❌ 无订单数据")
            return {}
        
        # 支付方式分析
        if 'payment_method' in orders.columns:
            payment_stats = orders.groupby('payment_method').agg({
                'total_amount': 'sum',
                'order_id': 'count'
            }).rename(columns={'total_amount': 'amount', 'order_id': 'count'})
            
            payment_data = {}
            total_orders = len(orders)
            
            print("📊 支付方式分布:")
            for method, row in payment_stats.iterrows():
                percentage = (row['count'] / total_orders) * 100
                print(f"  {method}: {int(row['count'])} 笔 ({percentage:.1f}%)")
                print(f"      支付总额: ¥{row['amount']:,.2f}")
                payment_data[method] = {
                    'count': int(row['count']),
                    'amount': float(row['amount']),
                    'percentage': float(percentage)
                }
            
            return {'payment_methods': payment_data}
        
        return {}
    
    def refund_analysis(self):
        """退款分析 - 返回可序列化的数据"""
        print("\n" + "="*60)
        print("🔄 退款分析")
        print("="*60)
        
        refunds = self.data['refunds']
        orders = self.data['orders']
        
        if refunds.empty:
            print("❌ 无退款数据")
            return {}
        
        # 退款总体统计
        total_refunds = float(refunds['refund_amount'].sum())
        total_orders = len(orders) if not orders.empty else 0
        refund_count = len(refunds)
        refund_rate = (refund_count / total_orders * 100) if total_orders > 0 else 0
        
        print(f"📊 退款统计:")
        print(f"  退款订单数: {refund_count} 笔")
        print(f"  退款总额: ¥{total_refunds:,.2f}")
        print(f"  整体退款率: {refund_rate:.2f}%")
        
        # 退款原因分析
        reason_data = {}
        if 'refund_reason' in refunds.columns:
            reason_stats = refunds.groupby('refund_reason').agg({
                'refund_amount': 'sum',
                'refund_id': 'count'
            }).rename(columns={'refund_amount': 'amount', 'refund_id': 'count'})
            
            print("\n📋 退款原因分析:")
            for reason, row in reason_stats.iterrows():
                percentage = (row['count'] / refund_count) * 100
                print(f"  {reason}: {int(row['count'])} 笔 ({percentage:.1f}%)")
                print(f"      退款总额: ¥{row['amount']:,.2f}")
                reason_data[reason] = {
                    'count': int(row['count']),
                    'amount': float(row['amount']),
                    'percentage': float(percentage)
                }
        
        return {
            'total_refunds': total_refunds,
            'refund_count': refund_count,
            'refund_rate': refund_rate,
            'refund_reasons': reason_data
        }
    
    def generate_recommendations(self):
        """生成业务建议"""
        print("\n" + "="*60)
        print("💡 业务优化建议")
        print("="*60)
        
        recommendations = []
        
        # 基于销售分析的建议
        if not self.data['orders'].empty:
            orders = self.data['orders']
            orders['month'] = orders['order_date'].dt.strftime('%Y-%m')
            monthly_sales = orders.groupby('month')['total_amount'].sum()
            
            if len(monthly_sales) > 1:
                try:
                    sales_growth = ((monthly_sales.iloc[-1] - monthly_sales.iloc[-2]) / monthly_sales.iloc[-2]) * 100
                    if sales_growth < 0:
                        recommendations.append({
                            'category': '销售',
                            'priority': '高',
                            'suggestion': f'销售额环比下降 {abs(sales_growth):.1f}%，建议开展促销活动刺激消费',
                            'action': '策划限时折扣或满减活动'
                        })
                except:
                    pass
        
        # 基于客户分析的建议
        try:
            customer_result = self.customer_analysis()
            if 'customer_segments' in customer_result:
                if customer_result['customer_segments'].get('vip', 0) < 5:
                    recommendations.append({
                        'category': '客户',
                        'priority': '中',
                        'suggestion': 'VIP客户数量较少，建议加强客户关系管理',
                        'action': '制定VIP客户专属权益和个性化服务'
                    })
        except:
            pass
        
        # 基于用户行为分析的建议
        try:
            behavior_result = self.user_behavior_analysis()
            if 'conversion_rates' in behavior_result:
                cart_to_purchase = behavior_result['conversion_rates'].get('cart_to_purchase', 0)
                if cart_to_purchase < 30:
                    recommendations.append({
                        'category': '转化',
                        'priority': '中',
                        'suggestion': f'加购到购买转化率仅 {cart_to_purchase:.1f}%，存在购物车放弃问题',
                        'action': '优化购物车页面，添加优惠券提示或简化结算流程'
                    })
        except:
            pass
        
        print("📝 生成建议:")
        if recommendations:
            for i, rec in enumerate(recommendations, 1):
                print(f"\n  {i}. [{rec['priority']}] {rec['category']} - {rec['suggestion']}")
                print(f"     建议行动: {rec['action']}")
        else:
            print("  暂无业务建议")
        
        # 保存建议到文件
        try:
            os.makedirs('data/analysis', exist_ok=True)
            with open('data/analysis/business_recommendations.json', 'w', encoding='utf-8') as f:
                json.dump(recommendations, f, ensure_ascii=False, indent=2)
            
            print(f"\n📋 建议已保存至: data/analysis/business_recommendations.json")
        except Exception as e:
            print(f"⚠️ 保存建议失败: {e}")
        
        return recommendations
    
    def save_all_reports(self):
        """保存所有分析报告 - 专门为仪表板优化"""
        print("\n" + "="*60)
        print("💾 保存分析报告")
        print("="*60)
        
        # 确保目录存在
        os.makedirs('data/analysis', exist_ok=True)
        os.makedirs('data', exist_ok=True)
        
        try:
            # 1. 执行基本分析
            print("执行基本分析...")
            basic_stats = self.basic_statistics()
            
            # 2. 保存关键指标到CSV
            key_metrics = pd.DataFrame([{
                '指标': '总销售额',
                '数值': basic_stats.get('total_sales', 0),
                '单位': '元'
            }, {
                '指标': '总订单数',
                '数值': basic_stats.get('total_orders', 0),
                '单位': '笔'
            }, {
                '指标': '消费客户数',
                '数值': basic_stats.get('total_customers', 0),
                '单位': '人'
            }, {
                '指标': '平均订单额',
                '数值': basic_stats.get('avg_order_value', 0),
                '单位': '元'
            }, {
                '指标': '客单价',
                '数值': basic_stats.get('customer_value', 0),
                '单位': '元'
            }, {
                '指标': '购买转化率',
                '数值': basic_stats.get('conversion_rate', 0),
                '单位': '%'
            }, {
                '指标': '30天活跃用户',
                '数值': basic_stats.get('active_users', 0),
                '单位': '人'
            }])
            
            key_metrics.to_csv('data/analysis/key_metrics.csv', index=False, encoding='utf-8-sig')
            print(f"✅ 关键指标已保存至: data/analysis/key_metrics.csv")
            
            # 3. 生成并保存建议
            recommendations = self.generate_recommendations()
            
            # 4. 执行其他分析（只计算不保存复杂对象）
            print("\n执行深度分析...")
            sales_stats = self.sales_analysis()
            product_stats = self.product_analysis()
            customer_stats = self.customer_analysis()
            behavior_stats = self.user_behavior_analysis()
            payment_stats = self.payment_analysis()
            refund_stats = self.refund_analysis()
            
            # 5. 保存简化版的分析报告（可JSON序列化）
            simple_report = {
                'generation_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'basic_statistics': basic_stats,
                'recommendations': recommendations,
                'sales_summary': sales_stats.get('monthly_sales', {}),
                'category_summary': product_stats.get('category_stats', {}),
                'customer_summary': customer_stats.get('customer_segments', {}),
                'behavior_summary': behavior_stats.get('conversion_funnel', {})
            }
            
            with open('data/analysis/simple_report.json', 'w', encoding='utf-8') as f:
                json.dump(simple_report, f, ensure_ascii=False, indent=2)
            
            print(f"✅ 简化分析报告已保存至: data/analysis/simple_report.json")
            
        except Exception as e:
            print(f"⚠️ 保存分析报告过程中出现错误: {e}")
            import traceback
            traceback.print_exc()
        
        # 6. 最重要：为仪表板生成数据文件
        print("\n📊 为仪表板生成数据文件...")
        try:
            self._create_dashboard_data()
        except Exception as e:
            print(f"❌ 生成仪表板数据失败: {e}")
            import traceback
            traceback.print_exc()
        
        return {'success': True}
    
    def _create_dashboard_data(self):
        """为仪表板创建专门的JSON数据文件"""
        print("创建仪表板数据文件...")
        
        try:
            # 1. 创建订单数据
            if not self.data['orders'].empty:
                orders_df = self.data['orders'].copy()
                
                # 选择需要的列
                columns_needed = ['order_id', 'user_id', 'product_id', 'product_name', 
                                 'category', 'brand', 'unit_price', 'quantity',
                                 'total_amount', 'order_date', 'payment_method', 'status']
                
                # 确保列存在
                available_columns = [col for col in columns_needed if col in orders_df.columns]
                orders_df = orders_df[available_columns]
                
                # 转换日期为字符串
                if 'order_date' in orders_df.columns:
                    orders_df['order_date'] = orders_df['order_date'].dt.strftime('%Y-%m-%d %H:%M:%S')
                
                # 保存为JSON
                orders_json = orders_df.to_dict(orient='records')
                with open('data/processed_orders.json', 'w', encoding='utf-8') as f:
                    json.dump(orders_json, f, ensure_ascii=False, indent=2)
                
                print(f"  ✓ 已保存: data/processed_orders.json ({len(orders_json)} 条记录)")
            else:
                print("  ⚠️ 无订单数据")
                # 创建空文件避免错误
                with open('data/processed_orders.json', 'w', encoding='utf-8') as f:
                    json.dump([], f, ensure_ascii=False, indent=2)
        
        except Exception as e:
            print(f"  ❌ 保存订单数据失败: {e}")
            # 创建空文件避免错误
            with open('data/processed_orders.json', 'w', encoding='utf-8') as f:
                json.dump([], f, ensure_ascii=False, indent=2)
        
        try:
            # 2. 创建用户数据
            if not self.data['users'].empty:
                users_df = self.data['users'].copy()
                
                # 选择需要的列
                columns_needed = ['user_id', 'name', 'age', 'gender', 'city',
                                 'province', 'registration_date', 'membership_level',
                                 'total_spent', 'order_count']
                
                # 确保列存在
                available_columns = [col for col in columns_needed if col in users_df.columns]
                users_df = users_df[available_columns]
                
                # 转换日期为字符串
                if 'registration_date' in users_df.columns:
                    users_df['registration_date'] = users_df['registration_date'].dt.strftime('%Y-%m-%d')
                if 'last_purchase_date' in users_df.columns:
                    users_df['last_purchase_date'] = users_df['last_purchase_date'].dt.strftime('%Y-%m-%d')
                
                # 保存为JSON
                users_json = users_df.to_dict(orient='records')
                with open('data/user_profiles.json', 'w', encoding='utf-8') as f:
                    json.dump(users_json, f, ensure_ascii=False, indent=2)
                
                print(f"  ✓ 已保存: data/user_profiles.json ({len(users_json)} 条记录)")
            else:
                print("  ⚠️ 无用户数据")
                # 创建空文件避免错误
                with open('data/user_profiles.json', 'w', encoding='utf-8') as f:
                    json.dump([], f, ensure_ascii=False, indent=2)
        
        except Exception as e:
            print(f"  ❌ 保存用户数据失败: {e}")
            # 创建空文件避免错误
            with open('data/user_profiles.json', 'w', encoding='utf-8') as f:
                json.dump([], f, ensure_ascii=False, indent=2)
        
        try:
            # 3. 创建产品数据
            if not self.data['products'].empty:
                products_df = self.data['products'].copy()
                products_json = products_df.to_dict(orient='records')
                with open('data/product_catalog.json', 'w', encoding='utf-8') as f:
                    json.dump(products_json, f, ensure_ascii=False, indent=2)
                
                print(f"  ✓ 已保存: data/product_catalog.json ({len(products_json)} 条记录)")
            else:
                print("  ⚠️ 无产品数据")
                # 创建空文件避免错误
                with open('data/product_catalog.json', 'w', encoding='utf-8') as f:
                    json.dump([], f, ensure_ascii=False, indent=2)
        
        except Exception as e:
            print(f"  ❌ 保存产品数据失败: {e}")
            # 创建空文件避免错误
            with open('data/product_catalog.json', 'w', encoding='utf-8') as f:
                json.dump([], f, ensure_ascii=False, indent=2)
        
        print("✅ 仪表板数据文件创建完成！")
        print("\n📁 生成的文件:")
        print("  - data/processed_orders.json")
        print("  - data/user_profiles.json")
        print("  - data/product_catalog.json")

def main():
    """主函数"""
    print("🚀 电商数据分析平台")
    print("="*60)
    
    try:
        # 初始化分析器
        analyzer = EcommerceAnalyzer()
        
        # 执行完整分析
        print("\n开始执行完整数据分析流程...")
        print("-"*60)
        
        # 执行各项分析（显示结果但不保存复杂对象）
        analyzer.basic_statistics()
        analyzer.sales_analysis()
        analyzer.product_analysis()
        analyzer.customer_analysis()
        analyzer.user_behavior_analysis()
        analyzer.payment_analysis()
        analyzer.refund_analysis()
        
        # 生成并保存报告
        analyzer.generate_recommendations()
        analyzer.save_all_reports()
        
        print("\n" + "="*60)
        print("✅ 数据分析完成！")
        print("="*60)
        
        print("\n📁 生成的分析文件:")
        print("  📄 data/analysis/key_metrics.csv - 关键指标")
        print("  📄 data/analysis/business_recommendations.json - 业务建议")
        print("  📄 data/analysis/simple_report.json - 简化分析报告")
        
        print("\n📊 仪表板数据文件:")
        print("  📄 data/processed_orders.json - 订单数据")
        print("  📄 data/user_profiles.json - 用户数据")
        print("  📄 data/product_catalog.json - 产品数据")
        
        print("\n🎯 下一步:")
        print("  1. streamlit run src/dashboard.py - 运行仪表板")
        print("  2. 查看 business_recommendations.json 获取优化建议")
        
    except Exception as e:
        print(f"\n❌ 分析过程中出现错误: {e}")
        import traceback
        traceback.print_exc()
        print("\n请确保已运行 data_generator.py 生成数据")

if __name__ == "__main__":
    main()