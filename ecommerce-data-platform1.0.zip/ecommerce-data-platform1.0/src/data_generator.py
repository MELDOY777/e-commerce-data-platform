# src/data_generator.py
import pandas as pd
import numpy as np
from faker import Faker
import json
from datetime import datetime, timedelta
import random
import os
from typing import Dict, List, Any
import hashlib

class EcommerceDataGenerator:
    def __init__(self, seed: int = 42):
        """初始化数据生成器"""
        random.seed(seed)
        np.random.seed(seed)
        self.fake = Faker('zh_CN')
        self.fake.seed_instance(seed)
        
        # 初始化产品目录
        self.products = self._init_products()
        self.product_categories = list(set(p["category"] for p in self.products))
        self.product_brands = list(set(p["brand"] for p in self.products))
        
        self.users = []
        # 用户偏好映射：存储用户对品牌和品类的偏好
        self.user_preferences = {}
        
    def _init_products(self) -> List[Dict[str, Any]]:
        """初始化产品目录 - 扩展更多产品"""
        products = [
            # 手机类
            {"id": 1, "name": "iPhone 15 Pro", "category": "手机", "price": 8999, "brand": "Apple", "tags": ["高端", "旗舰", "iOS"]},
            {"id": 2, "name": "iPhone 15", "category": "手机", "price": 5999, "brand": "Apple", "tags": ["中端", "iOS"]},
            {"id": 3, "name": "华为 Mate 60 Pro", "category": "手机", "price": 6999, "brand": "华为", "tags": ["旗舰", "5G", "国产"]},
            {"id": 4, "name": "华为 P60", "category": "手机", "price": 4999, "brand": "华为", "tags": ["拍照", "中高端"]},
            {"id": 5, "name": "小米 14 Ultra", "category": "手机", "price": 6499, "brand": "小米", "tags": ["拍照", "旗舰", "性价比"]},
            {"id": 6, "name": "小米 14", "category": "手机", "price": 3999, "brand": "小米", "tags": ["性价比", "水桶机"]},
            {"id": 7, "name": "OPPO Find X7", "category": "手机", "price": 4499, "brand": "OPPO", "tags": ["拍照", "设计"]},
            {"id": 8, "name": "vivo X100", "category": "手机", "price": 3999, "brand": "vivo", "tags": ["拍照", "性能"]},
            {"id": 9, "name": "荣耀 Magic6", "category": "手机", "price": 4999, "brand": "荣耀", "tags": ["旗舰", "MagicOS"]},
            {"id": 10, "name": "三星 Galaxy S24", "category": "手机", "price": 5999, "brand": "三星", "tags": ["高端", "安卓"]},
            
            # 电脑类
            {"id": 11, "name": "MacBook Air M3", "category": "电脑", "price": 10999, "brand": "Apple", "tags": ["轻薄", "长续航"]},
            {"id": 12, "name": "MacBook Pro 16", "category": "电脑", "price": 19999, "brand": "Apple", "tags": ["高性能", "创作"]},
            {"id": 13, "name": "联想 ThinkPad X1", "category": "电脑", "price": 12999, "brand": "联想", "tags": ["商务", "可靠"]},
            {"id": 14, "name": "戴尔 XPS 13", "category": "电脑", "price": 9999, "brand": "戴尔", "tags": ["轻薄", "全面屏"]},
            {"id": 15, "name": "华为 MateBook X Pro", "category": "电脑", "price": 8999, "brand": "华为", "tags": ["全面屏", "多屏协同"]},
            {"id": 16, "name": "小米 Book Pro 16", "category": "电脑", "price": 7499, "brand": "小米", "tags": ["性价比", "高性能"]},
            
            # 平板类
            {"id": 17, "name": "iPad Pro 12.9", "category": "平板", "price": 9299, "brand": "Apple", "tags": ["创作", "生产力"]},
            {"id": 18, "name": "iPad Air", "category": "平板", "price": 4799, "brand": "Apple", "tags": ["轻薄", "多彩"]},
            {"id": 19, "name": "华为 MatePad Pro", "category": "平板", "price": 4299, "brand": "华为", "tags": ["生产力", "HarmonyOS"]},
            {"id": 20, "name": "小米平板 6 Pro", "category": "平板", "price": 2799, "brand": "小米", "tags": ["性价比", "高刷"]},
            
            # 耳机类
            {"id": 21, "name": "AirPods Pro 2", "category": "耳机", "price": 1999, "brand": "Apple", "tags": ["降噪", "空间音频"]},
            {"id": 22, "name": "AirPods 3", "category": "耳机", "price": 1399, "brand": "Apple", "tags": ["舒适", "半入耳"]},
            {"id": 23, "name": "华为 FreeBuds Pro 3", "category": "耳机", "price": 1499, "brand": "华为", "tags": ["降噪", "星闪"]},
            {"id": 24, "name": "小米 Buds 4 Pro", "category": "耳机", "price": 999, "brand": "小米", "tags": ["降噪", "性价比"]},
            {"id": 25, "name": "索尼 WH-1000XM5", "category": "耳机", "price": 2599, "brand": "索尼", "tags": ["头戴式", "顶级降噪"]},
            
            # 智能穿戴
            {"id": 26, "name": "Apple Watch Ultra 2", "category": "智能穿戴", "price": 6499, "brand": "Apple", "tags": ["户外", "专业"]},
            {"id": 27, "name": "Apple Watch Series 9", "category": "智能穿戴", "price": 2999, "brand": "Apple", "tags": ["健康", "智能"]},
            {"id": 28, "name": "华为 Watch GT 4", "category": "智能穿戴", "price": 1588, "brand": "华为", "tags": ["长续航", "健康"]},
            {"id": 29, "name": "小米手环 8 Pro", "category": "智能穿戴", "price": 399, "brand": "小米", "tags": ["性价比", "轻便"]},
            
            # 智能家居
            {"id": 30, "name": "小米智能音箱", "category": "智能家居", "price": 299, "brand": "小米", "tags": ["AI", "控制中心"]},
            {"id": 31, "name": "华为智慧屏", "category": "智能家居", "price": 5999, "brand": "华为", "tags": ["4K", "HarmonyOS"]},
            {"id": 32, "name": "扫地机器人", "category": "智能家居", "price": 3299, "brand": "石头", "tags": ["清洁", "自动"]},
        ]
        return products
    
    def _generate_user_preferences(self, user_id: int) -> Dict[str, Any]:
        """为每个用户生成独特的偏好"""
        # 基于用户ID生成确定性偏好（相同ID产生相同偏好）
        random.seed(user_id)
        
        # 品牌偏好：用户对某些品牌有更高偏好
        brand_preferences = {}
        for brand in self.product_brands:
            # 基础偏好 + 个人偏好的随机性
            base_pref = 0.5  # 基础偏好值
            personal_bias = random.uniform(-0.3, 0.3)  # 个人随机偏好
            brand_preferences[brand] = max(0.1, min(1.0, base_pref + personal_bias))
        
        # 品类偏好
        category_preferences = {}
        for category in self.product_categories:
            base_pref = 0.5
            personal_bias = random.uniform(-0.2, 0.4)
            category_preferences[category] = max(0.1, min(1.0, base_pref + personal_bias))
        
        return {
            "brand_preferences": brand_preferences,
            "category_preferences": category_preferences,
            "price_sensitivity": random.uniform(0.3, 0.9),  # 价格敏感度
            "tech_savviness": random.uniform(0.2, 1.0),     # 科技接受度
        }
    
    def generate_users(self, n: int = 200) -> pd.DataFrame:
        """生成用户数据"""
        print(f"生成 {n} 个用户...")
        
        users = []
        for i in range(n):
            user_id = i + 1
            registration_date = self.fake.date_between(start_date="-2y", end_date="today")
            
            # 根据注册时间决定会员等级可能性
            days_since_registration = (datetime.now().date() - registration_date).days
            if days_since_registration > 365:
                membership_weights = [0.1, 0.2, 0.3, 0.25, 0.15]  # 老用户更可能高等级
            else:
                membership_weights = [0.3, 0.3, 0.2, 0.15, 0.05]  # 新用户更多普通等级
            
            user = {
                "user_id": user_id,
                "username": self.fake.user_name(),
                "name": self.fake.name(),
                "email": self.fake.email(),
                "phone": self.fake.phone_number(),
                "age": random.choices(
                    [18, 25, 35, 45, 55, 65],
                    weights=[0.15, 0.35, 0.25, 0.15, 0.08, 0.02]
                )[0],
                "gender": random.choice(["男", "女"]),
                "city": self.fake.city(),
                "province": self.fake.province(),
                "registration_date": registration_date,
                "membership_level": random.choices(
                    ["普通", "白银", "黄金", "铂金", "钻石"],
                    weights=membership_weights
                )[0],
                "total_spent": 0,  # 初始值，后面会更新
                "order_count": 0,  # 初始值
                "last_purchase_date": None,
            }
            users.append(user)
            
            # 生成用户偏好
            self.user_preferences[user_id] = self._generate_user_preferences(user_id)
        
        self.users = users
        return pd.DataFrame(users)
    
    def _weighted_product_choice(self, user_id: int) -> Dict[str, Any]:
        """基于用户偏好选择产品"""
        prefs = self.user_preferences.get(user_id, {})
        brand_prefs = prefs.get("brand_preferences", {})
        category_prefs = prefs.get("category_preferences", {})
        price_sensitivity = prefs.get("price_sensitivity", 0.5)
        tech_savviness = prefs.get("tech_savviness", 0.5)
        
        # 计算每个产品的权重
        weights = []
        for product in self.products:
            weight = 1.0
            
            # 品牌偏好影响
            brand_weight = brand_prefs.get(product["brand"], 0.5)
            weight *= brand_weight
            
            # 品类偏好影响
            category_weight = category_prefs.get(product["category"], 0.5)
            weight *= category_weight
            
            # 价格敏感度影响：价格敏感用户更倾向低价产品
            normalized_price = product["price"] / 20000  # 归一化到0-1
            price_factor = 1 - price_sensitivity * normalized_price
            weight *= price_factor
            
            # 科技接受度影响：科技接受度高的用户更倾向高端产品
            if any(tag in ["高端", "旗舰", "高性能"] for tag in product.get("tags", [])):
                weight *= tech_savviness
            
            weights.append(weight)
        
        # 基于权重选择产品
        total_weight = sum(weights)
        if total_weight == 0:
            return random.choice(self.products)
        
        r = random.uniform(0, total_weight)
        cumulative = 0
        for i, weight in enumerate(weights):
            cumulative += weight
            if r <= cumulative:
                return self.products[i]
        
        return random.choice(self.products)
    
    def generate_orders(self, n: int = 2000) -> pd.DataFrame:
        """生成订单数据"""
        if not self.users:
            self.generate_users(200)
            
        print(f"生成 {n} 条订单...")
        
        orders = []
        user_stats = {user["user_id"]: {"spent": 0, "count": 0} for user in self.users}
        
        # 时间权重：模拟节假日和促销日
        def get_date_weight(date):
            # 周末权重更高
            weekday = date.weekday()
            base_weight = 1.5 if weekday >= 5 else 1.0
            
            # 模拟促销日（每月1-3号，11.11，12.12等）
            if date.month == 11 and date.day == 11:  # 双十一
                return 5.0
            elif date.month == 12 and date.day == 12:  # 双十二
                return 3.0
            elif date.day <= 3:  # 月初
                return 1.8
            elif date.month == 6 and date.day == 18:  # 618
                return 4.0
            else:
                return base_weight
        
        for i in range(n):
            # 基于用户活跃度选择用户（已消费用户更可能继续购买）
            user_weights = []
            for user in self.users:
                base_weight = 1.0
                # 历史消费用户权重更高
                if user_stats[user["user_id"]]["count"] > 0:
                    base_weight += user_stats[user["user_id"]]["count"] * 0.5
                # 近期购买过的用户权重更高
                user_weights.append(base_weight)
            
            user = random.choices(self.users, weights=user_weights)[0]
            
            # 基于用户偏好选择产品
            product = self._weighted_product_choice(user["user_id"])
            
            quantity = random.choices(
                [1, 2, 3, 4, 5],
                weights=[0.6, 0.2, 0.1, 0.05, 0.05]
            )[0]
            
            # 折扣逻辑：根据会员等级和产品价格
            base_discount = 1.0
            membership_discounts = {
                "普通": 1.0,
                "白银": 0.98,
                "黄金": 0.95,
                "铂金": 0.92,
                "钻石": 0.88
            }
            base_discount *= membership_discounts[user["membership_level"]]
            
            # 高价产品更可能有折扣
            if product["price"] > 5000:
                base_discount *= random.choice([1.0, 0.95, 0.9])
            
            # 促销日额外折扣
            order_date = self.fake.date_time_between(start_date="-90d", end_date="now")
            if order_date.month == 11 and order_date.day == 11:
                base_discount *= random.uniform(0.7, 0.9)
            
            discount_rate = round(base_discount, 2)
            total_amount = round(product["price"] * quantity * discount_rate, 2)
            
            # 支付方式偏好：年轻人更倾向移动支付
            age_group = user["age"]
            if age_group < 30:
                payment_weights = [0.4, 0.4, 0.1, 0.08, 0.02]  # 更多移动支付
            elif age_group < 50:
                payment_weights = [0.3, 0.3, 0.2, 0.15, 0.05]  # 均衡
            else:
                payment_weights = [0.2, 0.2, 0.3, 0.2, 0.1]    # 更多传统支付
            
            payment_method = random.choices(
                ["支付宝", "微信支付", "信用卡", "花呗", "银联"],
                weights=payment_weights
            )[0]
            
            # 订单状态概率分布
            status_weights = [0.7, 0.15, 0.05, 0.05, 0.05]  # 大部分已完成
            status = random.choices(
                ["已完成", "已发货", "待付款", "已取消", "退款中"],
                weights=status_weights
            )[0]
            
            order = {
                "order_id": f"ORD{i+1:07d}",
                "user_id": user["user_id"],
                "product_id": product["id"],
                "product_name": product["name"],
                "category": product["category"],
                "brand": product["brand"],
                "unit_price": product["price"],
                "quantity": quantity,
                "discount_rate": discount_rate,
                "total_amount": total_amount,
                "order_date": order_date,
                "payment_method": payment_method,
                "shipping_city": user["city"],
                "shipping_province": user["province"],
                "status": status,
                "profit_margin": round(product["price"] * 0.15 * quantity, 2),  # 假设15%利润率
            }
            orders.append(order)
            
            # 更新用户统计
            user_stats[user["user_id"]]["spent"] += total_amount
            user_stats[user["user_id"]]["count"] += 1
        
        df = pd.DataFrame(orders)
        df["order_date"] = pd.to_datetime(df["order_date"])
        
        # 更新用户表中的消费统计
        for user in self.users:
            user["total_spent"] = user_stats[user["user_id"]]["spent"]
            user["order_count"] = user_stats[user["user_id"]]["count"]
            # 找到用户的最后购买日期
            user_orders = df[df["user_id"] == user["user_id"]]
            if not user_orders.empty:
                user["last_purchase_date"] = user_orders["order_date"].max()
        
        return df
    
    def generate_user_behavior(self, n: int = 10000) -> pd.DataFrame:
        """生成用户行为数据（浏览、点击等）"""
        print(f"生成 {n} 条用户行为...")
        
        if not self.users:
            self.generate_users(200)
            
        behaviors = []
        event_id_counter = 1
        
        # 行为类型权重
        behavior_weights = {
            "view": 0.5,
            "click": 0.3,
            "add_to_cart": 0.1,
            "add_to_wishlist": 0.06,
            "share": 0.04
        }
        
        behavior_types = list(behavior_weights.keys())
        behavior_probs = list(behavior_weights.values())
        
        # 为每个活跃用户生成行为
        active_users = [u for u in self.users if u.get("order_count", 0) > 0]
        if not active_users:
            active_users = random.sample(self.users, min(50, len(self.users)))
        
        for user in active_users:
            user_id = user["user_id"]
            prefs = self.user_preferences.get(user_id, {})
            
            # 活跃用户的平均行为数量
            avg_behaviors = max(10, int(user.get("order_count", 1) * 5))
            user_behavior_count = int(np.random.poisson(avg_behaviors))
            user_behavior_count = min(user_behavior_count, 200)  # 上限
            
            for _ in range(user_behavior_count):
                # 基于用户偏好选择产品
                product = self._weighted_product_choice(user_id)
                
                # 行为类型
                behavior_type = random.choices(behavior_types, weights=behavior_probs)[0]
                
                # 事件时间：基于用户最后活跃时间
                if user.get("last_purchase_date"):
                    start_date = user["last_purchase_date"] - timedelta(days=30)
                    end_date = user["last_purchase_date"]
                else:
                    start_date = datetime.now() - timedelta(days=30)
                    end_date = datetime.now()
                
                event_time = self.fake.date_time_between(start_date=start_date, end_date=end_date)
                
                # 设备和浏览器偏好
                device_prefs = {
                    "iPhone": 0.3 if "Apple" in prefs.get("brand_preferences", {}) else 0.1,
                    "Android": 0.5,
                    "PC": 0.15,
                    "iPad": 0.05 if "Apple" in prefs.get("brand_preferences", {}) else 0.01
                }
                device = random.choices(list(device_prefs.keys()), weights=list(device_prefs.values()))[0]
                
                browser_prefs = {
                    "Chrome": 0.5,
                    "Safari": 0.3 if device in ["iPhone", "iPad"] else 0.1,
                    "Firefox": 0.1,
                    "Edge": 0.1
                }
                browser = random.choices(list(browser_prefs.keys()), weights=list(browser_prefs.values()))[0]
                
                behavior = {
                    "event_id": f"EVT{event_id_counter:08d}",
                    "user_id": user_id,
                    "product_id": product["id"],
                    "product_name": product["name"],
                    "category": product["category"],
                    "brand": product["brand"],
                    "behavior_type": behavior_type,
                    "event_time": event_time,
                    "page_url": f"/product/{product['id']}",
                    "device": device,
                    "browser": browser,
                    "session_id": hashlib.md5(f"{user_id}_{event_time.date()}".encode()).hexdigest()[:8],
                    "duration_seconds": random.randint(10, 300) if behavior_type in ["view", "click"] else 0
                }
                behaviors.append(behavior)
                event_id_counter += 1
        
        # 如果行为数量不足，补充随机行为
        if len(behaviors) < n:
            additional_needed = n - len(behaviors)
            for i in range(additional_needed):
                user = random.choice(self.users)
                product = random.choice(self.products)
                
                behavior = {
                    "event_id": f"EVT{event_id_counter:08d}",
                    "user_id": user["user_id"],
                    "product_id": product["id"],
                    "product_name": product["name"],
                    "category": product["category"],
                    "brand": product["brand"],
                    "behavior_type": random.choices(behavior_types, weights=behavior_probs)[0],
                    "event_time": self.fake.date_time_between(start_date="-7d", end_date="now"),
                    "page_url": f"/product/{product['id']}",
                    "device": random.choice(["iPhone", "Android", "PC", "iPad"]),
                    "browser": random.choice(["Chrome", "Safari", "Firefox", "Edge"]),
                    "session_id": self.fake.uuid4()[:8],
                    "duration_seconds": random.randint(5, 180)
                }
                behaviors.append(behavior)
                event_id_counter += 1
        
        df = pd.DataFrame(behaviors)
        df["event_time"] = pd.to_datetime(df["event_time"])
        return df
    
    def generate_refunds(self, orders_df: pd.DataFrame) -> pd.DataFrame:
        """基于订单数据生成退款数据"""
        print("生成退款数据...")
        
        # 从订单中筛选可能退款的订单
        refundable_orders = orders_df[
            (orders_df["status"] == "已完成") | 
            (orders_df["status"] == "已发货")
        ].copy()
        
        if refundable_orders.empty:
            return pd.DataFrame()
        
        # 退款概率：高价产品、特定品类退款率更高
        refund_probs = []
        for _, order in refundable_orders.iterrows():
            base_prob = 0.02  # 基础退款率2%
            
            # 高价产品退款率更高
            if order["total_amount"] > 5000:
                base_prob *= 2
            
            # 特定品类退款率调整
            if order["category"] == "手机":
                base_prob *= 1.5
            elif order["category"] == "电脑":
                base_prob *= 1.3
            
            refund_probs.append(base_prob)
        
        # 选择要退款的订单
        refund_mask = np.random.random(len(refundable_orders)) < refund_probs
        refund_orders = refundable_orders[refund_mask].copy()
        
        refunds = []
        for i, (_, order) in enumerate(refund_orders.iterrows()):
            refund_date = order["order_date"] + timedelta(
                days=random.randint(1, 30)
            )
            
            refund_reasons = [
                "商品质量问题",
                "与描述不符",
                "发货延迟",
                "商品损坏",
                "七天无理由",
                "其他原因"
            ]
            
            refund_amount = order["total_amount"] * random.uniform(0.5, 1.0)
            
            refund = {
                "refund_id": f"REF{i+1:06d}",
                "order_id": order["order_id"],
                "user_id": order["user_id"],
                "product_id": order["product_id"],
                "refund_amount": round(refund_amount, 2),
                "original_amount": order["total_amount"],
                "refund_reason": random.choice(refund_reasons),
                "refund_date": refund_date,
                "refund_status": random.choice(["已完成", "处理中", "已拒绝"]),
                "refund_type": random.choice(["全额退款", "部分退款"]),
            }
            refunds.append(refund)
        
        if refunds:
            df = pd.DataFrame(refunds)
            df["refund_date"] = pd.to_datetime(df["refund_date"])
            return df
        return pd.DataFrame()
    
    def save_to_files(self, config: Dict[str, int] = None) -> Dict[str, pd.DataFrame]:
        """保存所有数据到文件"""
        if config is None:
            config = {
                "users": 200,
                "orders": 2000,
                "behaviors": 10000,
            }
        
        # 创建数据目录
        os.makedirs("data/raw", exist_ok=True)
        os.makedirs("data/processed", exist_ok=True)
        os.makedirs("data/analysis", exist_ok=True)
        
        print("="*60)
        print("开始生成电商模拟数据...")
        print("="*60)
        
        # 1. 生成用户数据
        print(f"\n📊 阶段1/5: 生成用户数据 ({config['users']} 个用户)")
        users_df = self.generate_users(config['users'])
        users_df.to_csv("data/raw/users.csv", index=False, encoding="utf-8-sig")
        print(f"   ✓ 已保存: data/raw/users.csv ({len(users_df)} 条记录)")
        
        # 2. 生成订单数据
        print(f"\n📦 阶段2/5: 生成订单数据 ({config['orders']} 笔订单)")
        orders_df = self.generate_orders(config['orders'])
        orders_df.to_csv("data/raw/orders.csv", index=False, encoding="utf-8-sig")
        print(f"   ✓ 已保存: data/raw/orders.csv ({len(orders_df)} 条记录)")
        
        # 3. 生成退款数据
        print(f"\n🔄 阶段3/5: 生成退款数据")
        refunds_df = self.generate_refunds(orders_df)
        if not refunds_df.empty:
            refunds_df.to_csv("data/raw/refunds.csv", index=False, encoding="utf-8-sig")
            print(f"   ✓ 已保存: data/raw/refunds.csv ({len(refunds_df)} 条记录)")
        else:
            print("   ⓘ 无退款数据生成")
        
        # 4. 生成用户行为数据
        print(f"\n🖱️ 阶段4/5: 生成用户行为数据 ({config['behaviors']} 条行为)")
        behavior_df = self.generate_user_behavior(config['behaviors'])
        behavior_df.to_csv("data/raw/user_behavior.csv", index=False, encoding="utf-8-sig")
        print(f"   ✓ 已保存: data/raw/user_behavior.csv ({len(behavior_df)} 条记录)")
        
        # 5. 保存产品目录
        print(f"\n🏷️ 阶段5/5: 保存产品目录")
        products_df = pd.DataFrame(self.products)
        products_df.to_csv("data/raw/products.csv", index=False, encoding="utf-8-sig")
        print(f"   ✓ 已保存: data/raw/products.csv ({len(products_df)} 条记录)")
        
        # 6. 保存用户偏好（用于分析）
        preferences_df = pd.DataFrame([
            {"user_id": uid, **prefs}
            for uid, prefs in self.user_preferences.items()
        ])
        preferences_df.to_csv("data/processed/user_preferences.csv", index=False, encoding="utf-8-sig")
        
        # 7. 生成汇总报告
        print(f"\n📈 生成数据分析报告...")
        self.generate_report(orders_df, users_df, behavior_df, refunds_df)
        
        return {
            "users": users_df,
            "orders": orders_df,
            "behavior": behavior_df,
            "products": products_df,
            "refunds": refunds_df,
            "preferences": preferences_df
        }
    
    def generate_report(self, orders_df: pd.DataFrame, users_df: pd.DataFrame, 
                       behavior_df: pd.DataFrame, refunds_df: pd.DataFrame):
        """生成详细的数据分析报告"""
        print("\n" + "="*60)
        print("📊 电商数据综合分析报告")
        print("="*60)
        
        # 基本统计
        total_sales = orders_df["total_amount"].sum()
        avg_order_value = orders_df["total_amount"].mean()
        total_orders = len(orders_df)
        unique_customers = orders_df["user_id"].nunique()
        total_profit = orders_df["profit_margin"].sum() if "profit_margin" in orders_df.columns else 0
        
        print(f"\n📈 核心业务指标:")
        print(f"  💰 总销售额: {total_sales:,.2f} 元")
        print(f"  📊 平均订单额: {avg_order_value:,.2f} 元")
        print(f"  📦 总订单数: {total_orders} 笔")
        print(f"  👥 消费客户数: {unique_customers} 人")
        print(f"  🏆 客单价: {total_sales/unique_customers:,.2f} 元")
        if total_profit > 0:
            print(f"  💵 总利润: {total_profit:,.2f} 元")
            print(f"  📉 平均利润率: {(total_profit/total_sales*100):.1f}%")
        
        # 退款分析
        if not refunds_df.empty:
            total_refunds = refunds_df["refund_amount"].sum()
            refund_rate = (len(refunds_df) / total_orders) * 100
            print(f"\n🔄 退款分析:")
            print(f"  📉 退款订单数: {len(refunds_df)} 笔")
            print(f"  💸 退款总额: {total_refunds:,.2f} 元")
            print(f"  📊 退款率: {refund_rate:.2f}%")
            
            # 退款原因分布
            print(f"\n  📋 退款原因分布:")
            reason_counts = refunds_df["refund_reason"].value_counts()
            for reason, count in reason_counts.items():
                percentage = (count / len(refunds_df)) * 100
                print(f"    {reason}: {count} 次 ({percentage:.1f}%)")
        
        # 按品类统计
        print(f"\n📈 品类销售分析:")
        category_stats = orders_df.groupby("category").agg({
            "total_amount": ["sum", "count", "mean"],
            "product_id": "nunique"
        }).round(2)
        
        category_stats.columns = ["销售额", "订单数", "平均订单额", "产品数"]
        category_stats = category_stats.sort_values("销售额", ascending=False)
        
        for category, row in category_stats.iterrows():
            sales_share = (row["销售额"] / total_sales) * 100
            print(f"  {category}:")
            print(f"    销售额: {row['销售额']:,.2f} 元 ({sales_share:.1f}%)")
            print(f"    订单数: {row['订单数']} 笔")
            print(f"    产品数: {row['产品数']} 个")
            print(f"    平均订单额: {row['平均订单额']:,.2f} 元")
        
        # 按品牌统计
        print(f"\n🏷️ 品牌销售分析 (前10):")
        brand_stats = orders_df.groupby("brand").agg({
            "total_amount": ["sum", "count", "mean"],
            "product_id": "nunique"
        }).round(2)
        
        brand_stats.columns = ["销售额", "订单数", "平均订单额", "产品数"]
        brand_stats = brand_stats.sort_values("销售额", ascending=False).head(10)
        
        for brand, row in brand_stats.iterrows():
            sales_share = (row["销售额"] / total_sales) * 100
            print(f"  {brand}: {row['销售额']:,.2f} 元 ({sales_share:.1f}%) - {row['订单数']} 笔订单")
        
        # 用户行为分析
        print(f"\n🖱️ 用户行为分析:")
        total_behaviors = len(behavior_df)
        unique_behavior_users = behavior_df["user_id"].nunique()
        avg_behaviors_per_user = total_behaviors / unique_behavior_users if unique_behavior_users > 0 else 0
        
        print(f"  总行为数: {total_behaviors} 次")
        print(f"  活跃用户数: {unique_behavior_users} 人")
        print(f"  人均行为数: {avg_behaviors_per_user:.1f} 次")
        
        # 行为类型分布
        print(f"\n  📊 行为类型分布:")
        behavior_counts = behavior_df["behavior_type"].value_counts()
        for behavior_type, count in behavior_counts.items():
            percentage = (count / total_behaviors) * 100
            print(f"    {behavior_type}: {count} 次 ({percentage:.1f}%)")
        
        # 时间分析
        print(f"\n📅 时间趋势分析:")
        orders_df["order_date_only"] = orders_df["order_date"].dt.date
        daily_sales = orders_df.groupby("order_date_only")["total_amount"].sum()
        
        if len(daily_sales) > 1:
            avg_daily_sales = daily_sales.mean()
            max_daily_sales = daily_sales.max()
            min_daily_sales = daily_sales.min()
            sales_std = daily_sales.std()
            
            print(f"  日均销售额: {avg_daily_sales:,.2f} 元")
            print(f"  最高日销售额: {max_daily_sales:,.2f} 元")
            print(f"  最低日销售额: {min_daily_sales:,.2f} 元")
            print(f"  销售额波动: {sales_std:,.2f} 元")
            
            # 周度分析
            orders_df["weekday"] = orders_df["order_date"].dt.day_name()
            weekday_sales = orders_df.groupby("weekday")["total_amount"].sum()
            print(f"\n  📆 周度销售分布:")
            for day, sales in weekday_sales.items():
                print(f"    {day}: {sales:,.2f} 元")
        
        # 保存详细报告到JSON
        report = {
            "summary": {
                "total_sales": float(total_sales),
                "average_order_value": float(avg_order_value),
                "total_orders": int(total_orders),
                "unique_customers": int(unique_customers),
                "total_profit": float(total_profit) if total_profit > 0 else None,
                "profit_margin_percentage": float((total_profit/total_sales*100)) if total_profit > 0 else None
            },
            "category_analysis": category_stats.to_dict(),
            "top_brands": brand_stats.head(5).to_dict(),
            "behavior_analysis": {
                "total_behaviors": int(total_behaviors),
                "unique_behavior_users": int(unique_behavior_users),
                "behavior_distribution": behavior_counts.to_dict(),
                "avg_behaviors_per_user": float(avg_behaviors_per_user)
            },
            "time_analysis": {
                "daily_sales_stats": {
                    "mean": float(avg_daily_sales) if len(daily_sales) > 1 else None,
                    "max": float(max_daily_sales) if len(daily_sales) > 1 else None,
                    "min": float(min_daily_sales) if len(daily_sales) > 1 else None,
                    "std": float(sales_std) if len(daily_sales) > 1 else None
                },
                "weekday_distribution": weekday_sales.to_dict() if "weekday" in orders_df.columns else {}
            },
            "refund_analysis": {
                "total_refunds": float(total_refunds) if not refunds_df.empty else 0,
                "refund_count": len(refunds_df) if not refunds_df.empty else 0,
                "refund_rate": float(refund_rate) if not refunds_df.empty else 0,
                "refund_reasons": reason_counts.to_dict() if not refunds_df.empty else {}
            } if not refunds_df.empty else None,
            "generation_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "data_summary": {
                "users_count": len(users_df),
                "orders_count": len(orders_df),
                "products_count": len(self.products),
                "behaviors_count": len(behavior_df),
                "refunds_count": len(refunds_df) if not refunds_df.empty else 0
            }
        }
        
        with open("data/analysis/detailed_report.json", "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        # 保存CSV格式报告
        summary_df = pd.DataFrame([{
            "指标": "总销售额",
            "数值": total_sales,
            "单位": "元"
        }, {
            "指标": "平均订单额",
            "数值": avg_order_value,
            "单位": "元"
        }, {
            "指标": "总订单数",
            "数值": total_orders,
            "单位": "笔"
        }, {
            "指标": "消费客户数",
            "数值": unique_customers,
            "单位": "人"
        }, {
            "指标": "客单价",
            "数值": total_sales/unique_customers if unique_customers > 0 else 0,
            "单位": "元"
        }])
        
        summary_df.to_csv("data/analysis/business_summary.csv", index=False, encoding="utf-8-sig")
        
        print(f"\n📋 详细报告已保存:")
        print(f"  📁 data/analysis/detailed_report.json - 完整JSON报告")
        print(f"  📁 data/analysis/business_summary.csv - 业务指标摘要")
        print("="*60)

def main():
    """主函数"""
    print("🚀 高级电商数据分析平台 - 数据生成器")
    print("正在生成高质量的模拟电商数据...")
    
    # 配置数据规模
    config = {
        "users": 300,      # 用户数量
        "orders": 2500,    # 订单数量
        "behaviors": 15000, # 用户行为数量
    }
    
    print(f"\n配置参数:")
    print(f"  用户数: {config['users']}")
    print(f"  订单数: {config['orders']}")
    print(f"  行为数: {config['behaviors']}")
    
    generator = EcommerceDataGenerator(seed=42)  # 固定种子确保可重复性
    data = generator.save_to_files(config)
    
    print("\n" + "="*60)
    print("✅ 数据生成完成！")
    print("="*60)
    
    print("\n📁 生成的文件结构:")
    print("  📂 data/")
    print("    📂 raw/ (原始数据)")
    print("      📄 users.csv - 用户数据")
    print("      📄 orders.csv - 订单数据")
    print("      📄 user_behavior.csv - 用户行为数据")
    print("      📄 products.csv - 产品目录")
    print("      📄 refunds.csv - 退款数据")
    print("    📂 processed/ (处理数据)")
    print("      📄 user_preferences.csv - 用户偏好数据")
    print("    📂 analysis/ (分析报告)")
    print("      📄 detailed_report.json - 详细分析报告")
    print("      📄 business_summary.csv - 业务指标摘要")
    
    print("\n💡 下一步建议:")
    print("  1. 📊 运行数据分析脚本进行深入分析")
    print("  2. 📈 使用可视化工具创建图表")
    print("  3. 🤖 训练推荐系统模型（基于用户偏好）")
    print("  4. 📉 进行客户细分和RFM分析")
    print("  5. 🔍 分析用户行为漏斗转化率")
    
    return data

if __name__ == "__main__":
    main()